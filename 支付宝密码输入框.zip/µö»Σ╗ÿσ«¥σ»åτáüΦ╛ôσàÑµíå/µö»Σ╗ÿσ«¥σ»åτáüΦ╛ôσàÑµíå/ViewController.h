//
//  ViewController.h
//  支付宝密码输入框
//
//  Created by 邹壮壮 on 16/8/29.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *keyboardButton;

@end

