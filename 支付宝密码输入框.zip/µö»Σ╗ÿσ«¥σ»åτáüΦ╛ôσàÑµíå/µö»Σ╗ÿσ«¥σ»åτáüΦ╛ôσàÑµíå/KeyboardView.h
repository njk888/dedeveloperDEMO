//
//  KeyboardView.h
//  支付宝密码输入框
//
//  Created by 邹壮壮 on 16/8/29.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KeyboardView : UIView
@property (nonatomic, strong) NSMutableArray *pwd;

-(void)callKeyboard;

-(void)closeKeyboard;

@property (nonatomic, copy) void (^getPassword)(NSString *password);
@end
