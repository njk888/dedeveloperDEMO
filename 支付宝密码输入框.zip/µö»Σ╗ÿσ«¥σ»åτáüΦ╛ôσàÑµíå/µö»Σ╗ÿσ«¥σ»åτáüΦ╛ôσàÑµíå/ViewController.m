//
//  ViewController.m
//  支付宝密码输入框
//
//  Created by 邹壮壮 on 16/8/29.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "ViewController.h"
#import "KeyboardView.h"
@interface ViewController ()
@property (nonatomic, strong) KeyboardView *keyboardView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [_keyboardButton sizeToFit];
    self.keyboardView = [[KeyboardView alloc]initWithFrame:self.view.frame];
    __weak __typeof(self) weakSelf = self;
    _keyboardView.getPassword = ^(NSString *password){
        UIAlertController *ac = [UIAlertController alertControllerWithTitle:password message:nil preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleCancel handler:nil];
        [ac addAction:action];
        [weakSelf presentViewController:ac animated:YES completion:nil];
    };
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)keybutton:(id)sender {
    [self.view addSubview:_keyboardView];
    [_keyboardView callKeyboard];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
