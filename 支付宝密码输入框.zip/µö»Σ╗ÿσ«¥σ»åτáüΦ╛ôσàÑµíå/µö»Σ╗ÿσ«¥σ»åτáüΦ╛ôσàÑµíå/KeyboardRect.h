//
//  KeyboardRect.h
//  支付宝密码输入框
//
//  Created by 邹壮壮 on 16/8/29.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol GetpasswordDelegate <NSObject>

-(void)backPassword:(NSMutableArray *)_array;

-(void)closeKeyboard;

@end
@interface KeyboardRect : UIView
@property (nonatomic, strong) NSMutableArray *pwdArray;
@property (nonatomic, copy) NSMutableArray *(^callback)();

@property (nonatomic, assign) id<GetpasswordDelegate> getpasswordDelegate;
@end
