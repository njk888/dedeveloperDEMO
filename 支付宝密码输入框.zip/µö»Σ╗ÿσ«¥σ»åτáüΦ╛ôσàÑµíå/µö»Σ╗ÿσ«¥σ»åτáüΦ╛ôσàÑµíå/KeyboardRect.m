//
//  KeyboardRect.m
//  支付宝密码输入框
//
//  Created by 邹壮壮 on 16/8/29.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "KeyboardRect.h"
#define sWidth [UIScreen mainScreen].bounds.size.width
#define sHeight [UIScreen mainScreen].bounds.size.height
#define keyHeight sHeight*0.6
#define mHexColor(hex, alphaValue) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16))/255.0 green:((float)((hex & 0xFF00) >> 8))/255.0 blue:((float)(hex & 0xFF))/255.0 alpha:alphaValue]

#define Start_X 0
#define Start_Y 0
#define Width_Space 0
#define Height_Space 0
//键盘
@interface KeyboardRect ()
{
    NSMutableArray *_buttonArray;
    CGFloat _buttonWidth;
    CGFloat _buttonHeight;
}
@end
@implementation KeyboardRect
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        _pwdArray            = [[NSMutableArray alloc]init];
        _buttonWidth         = frame.size.width/3;
        _buttonHeight        = frame.size.height/4;
        [self createNumberButton];
    }
    return self;
}

- (void)createNumberButton{
    _buttonArray = [NSMutableArray arrayWithArray:@[@"1",@"2",@"3",
                                                    @"4",@"5",@"6",
                                                    @"7",@"8",@"9",
                                                    @"清除",@"0",@"后退"]];
    for (int i = 0 ; i < 12; i++) {
        NSInteger index = i % 3;
        NSInteger page = i / 3;
        
        
        // 圆角按钮
        UIButton *aBt = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        
        
        aBt.frame = CGRectMake(index * (_buttonWidth + Width_Space) + Start_X, page  * (_buttonHeight + Height_Space)+Start_Y, _buttonWidth, _buttonHeight);
        
        
        aBt.tag = i;
        [aBt setTitle:_buttonArray[i] forState:UIControlStateNormal];
        [aBt setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [aBt setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
        [aBt addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        aBt.layer.borderColor = [UIColor grayColor].CGColor;
        aBt.layer.borderWidth = 0.25;
        [self addSubview:aBt];
    }
}
-(void)buttonClick:(UIButton *)sender{
    if ((sender.tag >= 0 && sender.tag <= 8) || sender.tag == 10) {
        if (_pwdArray.count < 6) {
            [_pwdArray addObject:sender.titleLabel.text];
        }
    }else if (sender.tag == 9){
        [_pwdArray removeAllObjects];
    }else{
        [_pwdArray removeLastObject];
    }
    [self.getpasswordDelegate backPassword:_pwdArray];
}
@end
