//
//  Header.h
//  交往
//
//  Created by zou145688 on 15/10/20.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#ifndef Header_h
#define Header_h
#define kAppkey @"2592771385"
#define kRedirectURL @"http://weibo.com/u/5603345060/home?wvr=5"
#define NSLocalizedString(key, comment) \
[[NSBundle mainBundle] localizedStringForKey:(key) value:@"" table:nil]
#endif /* Header_h */
