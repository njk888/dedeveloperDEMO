//
//  AppDelegate.h
//  交往
//
//  Created by zou145688 on 15/10/20.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    NSString *WBtoken;
    NSString *WBuserID;
}
@property (strong, nonatomic) UIWindow *window;


@property (nonatomic, strong) NSString *WBtoken;
@property (nonatomic, strong) NSString *WBuserID;
@end

