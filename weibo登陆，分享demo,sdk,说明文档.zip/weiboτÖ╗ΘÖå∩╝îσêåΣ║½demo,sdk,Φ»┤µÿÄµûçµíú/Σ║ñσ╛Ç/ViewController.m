 //
//  ViewController.m
//  交往
//
//  Created by zou145688 on 15/10/20.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"
#import "WeiboSDK.h"
#import "Header.h"
#import "AppDelegate.h"
@interface ViewController ()<WBHttpRequestDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configView];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)configView{
    UIButton *sendBtn = [[UIButton alloc]initWithFrame:CGRectMake(120, 120, 80, 30)];
    [sendBtn setTitle:@"微博登陆" forState:UIControlStateNormal];
    sendBtn.backgroundColor = [UIColor redColor];
    [sendBtn addTarget:self action:@selector(sendWeiboAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sendBtn];
    UIButton *outWeiboBtn = [[UIButton alloc]initWithFrame:CGRectMake(120, 180, 60, 30)];
    [outWeiboBtn setTitle:@"退出" forState:UIControlStateNormal];
    [outWeiboBtn setBackgroundColor:[UIColor blackColor]];
    [outWeiboBtn addTarget:self action:@selector(outWeiboAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:outWeiboBtn];
    UIButton *shanreToWeiboBtn = [[UIButton alloc]initWithFrame:CGRectMake(120, 250, 120, 30)];
    shanreToWeiboBtn.backgroundColor = [UIColor greenColor];
    [shanreToWeiboBtn setTitle:@"分享到微博" forState:UIControlStateNormal];
    [shanreToWeiboBtn addTarget:self action:@selector(shareToWeiboAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:shanreToWeiboBtn];
    UIButton *messageRegisterButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [messageRegisterButton setTitle:NSLocalizedString(@"短信注册测试", nil) forState:UIControlStateNormal];
    [messageRegisterButton addTarget:self action:@selector(messageRegisterPressed:) forControlEvents:UIControlEventTouchUpInside];
    messageRegisterButton.frame = CGRectMake(120, 300, 130, 50);
    [self.view addSubview:messageRegisterButton];
    UIButton *appRecomendButton1 = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [appRecomendButton1 setTitle:NSLocalizedString(@"邀请微博好友", nil) forState:UIControlStateNormal];
    [appRecomendButton1 addTarget:self action:@selector(appRecommendButton1Pressed:) forControlEvents:UIControlEventTouchUpInside];
    appRecomendButton1.frame = CGRectMake(120, 380, 130, 50);
    [self.view addSubview:appRecomendButton1];
}
//微博登陆
- (void)sendWeiboAction:(id)sender{
    WBAuthorizeRequest *request = [WBAuthorizeRequest request];
    request.redirectURI = kRedirectURL;
    request.scope = @"all";
    request.userInfo = @{@"SSO_From":@"ViewController"
                         
                         };
    [WeiboSDK sendRequest:request];
}
//退出微博
- (void)outWeiboAction:(id)sender{
    AppDelegate *myAppDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    [WeiboSDK logOutWithToken:myAppDelegate.WBtoken delegate:self withTag:@"1"];
   
}
- (void)request:(WBHttpRequest *)request didFinishLoadingWithResult:(NSString *)result{
    NSLog(@"result=%@",result);
}
- (void)request:(WBHttpRequest *)request didFinishLoadingWithDataResult:(NSData *)data{
    NSLog(@"data=%@",data);
}
- (void)request:(WBHttpRequest *)request didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
}
//微博分享
- (void)shareToWeiboAction:(id)sender{
    AppDelegate *myAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    WBAuthorizeRequest *weiboRequest = [WBAuthorizeRequest request];
    weiboRequest.redirectURI = kRedirectURL;
    weiboRequest.scope = @"all";
    WBSendMessageToWeiboRequest *request = [WBSendMessageToWeiboRequest requestWithMessage:[self messageToShare] authInfo:weiboRequest access_token:myAppDelegate.WBtoken];
    request.userInfo = @{
                         @"ShareMessageFrom":@"ViewController"
                         };
    [WeiboSDK sendRequest:request];
}
//消息中图片内容和多媒体内容不能共存
- (WBMessageObject *)messageToShare{
//    文字内容
    WBMessageObject *message = [WBMessageObject message];
    message.text = NSLocalizedString(@"test微博weiboSDK发送文字到微博", nil);
//    图片内容
    WBImageObject *image = [WBImageObject object];
    image.imageData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle]pathForResource:@"Icon-Small-40@2x" ofType:@"png"]];
//   message.imageObject = image;
//    多媒体内容
    WBWebpageObject *webObject = [WBWebpageObject object];
//    对象唯一ID，用于唯一标识一个多媒体内容
    webObject.objectID = @"wodeid";
//     多媒体内容标题
    webObject.title = NSLocalizedString(@"分享网页标题", nil);
//     多媒体内容描述
    webObject.description = [NSString stringWithFormat:NSLocalizedString(@"分享内容简介-%.0f", nil),[[NSDate date]timeIntervalSince1970]];
//     多媒体内容缩略图
    webObject.thumbnailData = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"Icon-Small-40@2x" ofType:@"png"]];
//    网页的url地址
    webObject.webpageUrl = @"http://weibo.com/u/5603345060";
    message.mediaObject = webObject;
    return message;
}
- (void)messageRegisterPressed:(id)sender{
    [WeiboSDK messageRegister:@"短信验证"];
}
- (void)appRecommendButton1Pressed:(id)sender{
    AppDelegate *myAppDelagate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    WBSDKAppRecommendRequest *request = [WBSDKAppRecommendRequest requestWithUIDs:nil access_token:myAppDelagate.WBtoken];
    request.userInfo = @{
                         @"ShareMessageFrom":@"ViewController"
                         };
    [WeiboSDK sendRequest:request];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
