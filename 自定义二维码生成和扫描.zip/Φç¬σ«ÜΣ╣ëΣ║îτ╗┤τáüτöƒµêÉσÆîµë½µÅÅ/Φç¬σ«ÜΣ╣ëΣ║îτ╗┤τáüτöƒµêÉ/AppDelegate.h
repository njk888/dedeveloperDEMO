//
//  AppDelegate.h
//  自定义二维码生成
//
//  Created by 邹壮壮 on 16/8/19.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

