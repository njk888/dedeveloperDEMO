//
//  UIImage+QRCore.h
//  自定义二维码生成
//
//  Created by 邹壮壮 on 16/8/19.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (QRCore)
+(UIImage *)defaults:(NSString *)content;
+(UIImage *)createSizeQR:(CGFloat)size content:(NSString *)content;
+ (UIImage*)imageBlackToTransparent:(UIImage*)image withRed:(CGFloat)red andGreen:(CGFloat)green andBlue:(CGFloat)blue;
@end
