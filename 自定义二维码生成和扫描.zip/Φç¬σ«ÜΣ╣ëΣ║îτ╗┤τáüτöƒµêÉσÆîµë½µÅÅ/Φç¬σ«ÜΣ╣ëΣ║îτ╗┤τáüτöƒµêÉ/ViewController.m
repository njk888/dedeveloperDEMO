//
//  ViewController.m
//  自定义二维码生成
//
//  Created by 邹壮壮 on 16/8/19.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+QRCore.h"
#import "QRCodeReaderViewController.h"

@interface ViewController ()<QRCodeReaderDelegate>
@property (weak, nonatomic) IBOutlet UITextField *textiFileQr;
@property (weak, nonatomic) IBOutlet UIImageView *QRcoreImageView;
@property (weak, nonatomic) IBOutlet UIButton *scannerQR;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.edgesForExtendedLayout =UIRectEdgeNone;
//    self.automaticallyAdjustsScrollViewInsets = NO;
    _textiFileQr.clearButtonMode = UITextFieldViewModeWhileEditing;
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)createQRcore:(id)sender {
    UIImage *image = [UIImage createSizeQR:180 content:_textiFileQr.text];
    _QRcoreImageView.image = [UIImage imageBlackToTransparent:image withRed:112 andGreen:220 andBlue:120];
}
- (IBAction)scannerQR:(id)sender {
    QRCodeReaderViewController *readerQR = [[QRCodeReaderViewController alloc]init];
    readerQR.modalPresentationStyle = UIModalPresentationFormSheet;
    readerQR.delegate = self;
    __weak typeof(self) weakSelf = self;
    
    [readerQR setCompletionWithBlock:^(NSString *resultAsString) {
        [weakSelf.navigationController popViewControllerAnimated:YES];
        weakSelf.textiFileQr.text = resultAsString;
    }];
   
    [self.navigationController pushViewController:readerQR animated:YES];
    
}
#pragma mark - QRCodeReader Delegate Methods

- (void)reader:(QRCodeReaderViewController *)reader didScanResult:(NSString *)result
{
    [self dismissViewControllerAnimated:YES completion:^{
        NSLog(@"%@",result);
    }];
}

- (void)readerDidCancel:(QRCodeReaderViewController *)reader
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
