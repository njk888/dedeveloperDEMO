//
//  ViewController.h
//  KBRoundedButtonExample
//
//  Created by Kamil Burczyk on 01.09.2014.
//  Copyright (c) 2014 Sigmapoint. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
