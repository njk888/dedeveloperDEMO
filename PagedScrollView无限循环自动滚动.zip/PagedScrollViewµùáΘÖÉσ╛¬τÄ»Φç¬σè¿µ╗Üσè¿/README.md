PagedScrollView
===============

auto silde scrollview,manual timer control,module-designed
