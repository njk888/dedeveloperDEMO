//
//  ViewController.m
//  iapppaytest
//
//  Created by 邹壮壮 on 2017/3/17.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "ViewController.h"
#import "ZZNumberKeypad.h"

//----------------------设置随即颜色----------------------------
#define LRRandomColor [UIColor colorWithRed:arc4random_uniform(256)/255.0 green:arc4random_uniform(256)/255.0 blue:arc4random_uniform(256)/255.0 alpha:1.0]
@interface ViewController ()<ZZNumberKeypadDelegate>
@property (strong, nonatomic)  UITextField *appUserIdField;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 去消息通知中心订阅一条消息（当键盘将要显示时UIKeyboardWillShowNotification）执行相应的方法
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    
    //隐藏键盘
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    _appUserIdField = [[UITextField alloc]initWithFrame:CGRectMake(50, 180, 200, 50)];
    _appUserIdField.center = CGPointMake(self.view.frame.size.width/2, 180);
    _appUserIdField.backgroundColor = [UIColor grayColor];
    [self.view addSubview:_appUserIdField];
    //重置用户ID和自定义价格输入框的键盘
    ZZNumberKeypad *numberPad = [ZZNumberKeypad numberPadWithDelegate:self];
    UIButton *functionButton = numberPad.rigthFunctionButton;
    functionButton.titleLabel.adjustsFontSizeToFitWidth = YES;
    [functionButton setTitle:@"完成" forState:UIControlStateNormal];
    self.appUserIdField.inputView = numberPad;
    
    // Do any additional setup after loading the view, typically from a nib.
}
#pragma mark - APNumberPadDelegate Method
- (void)numberPad:(ZZNumberKeypad *)numberPad
   functionButton:(UIButton *)functionButton
        textInput:(UIResponder<UITextInput> *)textInput{
    if (![textInput isEqual:self.appUserIdField])
    {
        [textInput resignFirstResponder];
        return;
    }
     [textInput resignFirstResponder];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//当键盘将要显示时，将底部的view向上移到键盘的上面
-(void)keyboardWillShow:(NSNotification*)notification{
    //通过消息中的信息可以获取键盘的frame对象
    NSValue *keyboardObj = [[notification userInfo]objectForKey:UIKeyboardFrameEndUserInfoKey];
    // 获取键盘的尺寸,也即是将NSValue转变为CGRect
    CGRect keyrect;
    [keyboardObj getValue:&keyrect];
    NSLog(@"%f",keyrect.size.height);
    self.appUserIdField.backgroundColor = LRRandomColor;
    
}

//当键盘将要隐藏时（将原来移到键盘上面的视图还原）
-(void)keyboardWillHide:(NSNotification *)notification{
    
    NSValue *keyboardObj = [[notification userInfo]objectForKey:UIKeyboardFrameEndUserInfoKey];
    // 获取键盘的尺寸,也即是将NSValue转变为CGRect
    CGRect keyrect;
    [keyboardObj getValue:&keyrect];
   
    self.appUserIdField.backgroundColor = LRRandomColor;
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    if (![touch.view isKindOfClass:[self.appUserIdField class]]) {
        [self.appUserIdField resignFirstResponder];
    }
    
}
@end
