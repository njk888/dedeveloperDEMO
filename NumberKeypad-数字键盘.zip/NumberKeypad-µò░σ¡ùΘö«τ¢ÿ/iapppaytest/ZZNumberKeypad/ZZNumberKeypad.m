//
//  ZZNumberKeypad.m
//  iapppaytest
//
//  Created by 邹壮壮 on 2017/3/17.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import "ZZNumberKeypad.h"


#import "ZZNumberButton.h"

static inline UIColor* APNPRGBA(int r, int g, int b, CGFloat alpha)
{
    return [UIColor colorWithRed:r / 255.f
                           green:g / 255.f
                            blue:b / 255.f
                           alpha:alpha];
}

@interface ZZNumberKeypad ()
{
    BOOL _clearButtonLongPressGesture;
    
    struct {
        unsigned int textInputSupportsShouldChangeTextInRange:1;
        unsigned int delegateSupportsTextFieldShouldChangeCharactersInRange:1;
        unsigned int delegateSupportsTextViewShouldChangeTextInRange:1;
    } _delegateFlags;
}

/**
 *  Array of APNumberButton
 */
@property (copy, readwrite, nonatomic) NSArray *numberButtons;

/**
 *  Left function button
 */
@property (strong, readwrite, nonatomic) ZZNumberButton *leftButton;

/**
 *  APNumberPad delegate
 */
@property (weak, readwrite, nonatomic) id<ZZNumberKeypadDelegate> delegate;

/**
 *  Auto-detected text input
 */
@property (weak, readwrite, nonatomic) UIResponder<UITextInput> *textInput;

/**
 *  Last touch on view. For support tap by tap entering text
 */
@property (weak, readwrite, nonatomic) UITouch *lastTouch;

@end

@implementation ZZNumberKeypad

+ (instancetype)numberPadWithDelegate:(id<ZZNumberKeypadDelegate>)delegate
{
    return [[self alloc] initWithDelegate:delegate];
}

- (instancetype)initWithDelegate:(id<ZZNumberKeypadDelegate>)delegate
{
    self = [super initWithFrame:CGRectZero];
    if (self != nil)
    {
        //设置键盘视图的rect大小
        self.frame = [[self class] numberPadFrame];
        self.autoresizingMask = UIViewAutoresizingFlexibleHeight;
        self.backgroundColor = [[self class] numberPadBackgroundColor];
        
        //添加键盘的通知
        [self addNotificationsObservers];
        
        //保存代理对象
        self.delegate = delegate;
        
        //添加数字按钮到键盘视图上(0-9)
        NSMutableArray *numberButtons = [NSMutableArray array];
        for (int i = 0; i < 11; i ++)
        {
            ZZNumberButton *numberButton = [self numberButton:i];
            [self addSubview:numberButton];
            [numberButtons addObject:numberButton];
        }
        self.numberButtons = numberButtons;
        
        //创建左边的功能按钮视图(清除按钮)
        self.clearButton = [self clearNumButton];
        [self.clearButton setImage:[[self class] clearFunctionButtonImage]
                          forState:UIControlStateNormal];
        [self.clearButton setImage:[[self class] clearFunctionButtonImage]
                          forState:UIControlStateHighlighted];
        [self.clearButton addTarget:self
                             action:@selector(clearButtonAction)
                   forControlEvents:UIControlEventTouchUpInside];
        
        //为清除按钮添加长按手势
        SEL selector = @selector(longPressGestureRecognizerAction:);
        UILongPressGestureRecognizer *longPreGesture = nil;
        longPreGesture = [[UILongPressGestureRecognizer alloc] init];
        longPreGesture.cancelsTouchesInView = NO;
        [longPreGesture addTarget:self action:selector];
        [self.clearButton addGestureRecognizer:longPreGesture];
        [self addSubview:self.clearButton];
        
        //创建右边的功能按钮视图
        self.leftButton = [self functionButton];
        self.leftButton.titleLabel.font = [[self class] functionButtonFont];
        [self.leftButton setTitleColor:[[self class] functionButtonTextColor]
                              forState:UIControlStateNormal];
        [self.leftButton addTarget:self
                            action:@selector(functionButtonAction:)
                  forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.leftButton];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    int rows = 4;
    int sections = 3;
    
    CGFloat top = 0.f;
    CGFloat left = 0.f;
    CGFloat sep = [[self class] separator];
    
    //计算每个按钮的大小
#if defined(__LP64__) && __LP64__
    CGFloat buttonHeight = trunc((CGRectGetHeight(self.bounds)-sep*(rows-1))/rows)+sep;
#else
    CGFloat buttonHeight = truncf((CGRectGetHeight(self.bounds)-sep*(rows-1))/rows)+sep;
#endif
    CGFloat buttonWidth = CGRectGetWidth(self.bounds);
    buttonWidth = buttonWidth - (sep * (sections - 1));
    buttonWidth = buttonWidth / sections;
    CGSize buttonSize = CGSizeMake(buttonWidth,buttonHeight);
    
    //布局数字按钮到键盘视图上(1-9)
    for (int i = 1; i < self.numberButtons.count - 1; i ++)
    {
        ZZNumberButton *numberButton = self.numberButtons[i];
        numberButton.frame = CGRectMake(left, top,
                                        buttonSize.width,
                                        buttonSize.height);
        if (i % sections == 0) {
            left = 0.f;
            top += buttonSize.height + sep;
        } else {
            left += buttonSize.width + sep;
        }
    }
    
    //创建右边的功能按钮视图（清除按钮）
    left = 0.f;
    self.clearButton.frame = CGRectMake(left, top,
                                        buttonSize.width,
                                        buttonSize.height);
    
    //布局数字按钮到键盘视图上(0)
    left += buttonSize.width + sep;
    UIButton *zeroButton = self.numberButtons.firstObject;
    zeroButton.frame = CGRectMake(left, top,
                                  buttonSize.width,
                                  buttonSize.height);
    
    //布局左边的功能按钮视图
    left += buttonSize.width + sep;
    self.leftButton.frame = CGRectMake(left, top,
                                       buttonSize.width,
                                       buttonSize.height);
}

#pragma mark - Notifications Method
- (void)addNotificationsObservers
{
    NSNotificationCenter *notificationCenter = nil;
    notificationCenter = [NSNotificationCenter defaultCenter];
    [notificationCenter addObserver:self
                           selector:@selector(textDidBeginEditing:)
                               name:UITextFieldTextDidBeginEditingNotification
                             object:nil];
    [notificationCenter addObserver:self
                           selector:@selector(textDidBeginEditing:)
                               name:UITextViewTextDidBeginEditingNotification
                             object:nil];
    [notificationCenter addObserver:self
                           selector:@selector(textDidEndEditing:)
                               name:UITextFieldTextDidEndEditingNotification
                             object:nil];
    [notificationCenter addObserver:self
                           selector:@selector(textDidEndEditing:)
                               name:UITextViewTextDidEndEditingNotification
                             object:nil];
}

- (void)textDidBeginEditing:(NSNotification *)notification
{
    if (![notification.object conformsToProtocol:@protocol(UITextInput)])
    {
        return;
    }
    
    UIResponder<UITextInput> *textInput = notification.object;
    
    if (textInput.inputView && self == textInput.inputView)
    {
        self.textInput = textInput;
        
        _delegateFlags.textInputSupportsShouldChangeTextInRange = NO;
        _delegateFlags.delegateSupportsTextFieldShouldChangeCharactersInRange = NO;
        _delegateFlags.delegateSupportsTextViewShouldChangeTextInRange = NO;
        
        if ([self.textInput respondsToSelector:@selector(shouldChangeTextInRange:replacementText:)])
        {
            _delegateFlags.textInputSupportsShouldChangeTextInRange = YES;
        }
        else if ([self.textInput isKindOfClass:[UITextField class]])
        {
            id<UITextFieldDelegate> delegate = [(UITextField *)self.textInput delegate];
            if ([delegate respondsToSelector:@selector(textField:shouldChangeCharactersInRange:replacementString:)])
            {
                _delegateFlags.delegateSupportsTextFieldShouldChangeCharactersInRange = YES;
            }
        }
        else if ([self.textInput isKindOfClass:[UITextView class]])
        {
            id<UITextViewDelegate> delegate = [(UITextView *)self.textInput delegate];
            if ([delegate respondsToSelector:@selector(textView:shouldChangeTextInRange:replacementText:)])
            {
                _delegateFlags.delegateSupportsTextViewShouldChangeTextInRange = YES;
            }
        }
    }
}

- (void)textDidEndEditing:(NSNotification *)notification
{
    self.textInput = nil;
}



#pragma mark - UIResponder
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [[UIDevice currentDevice] playInputClick];
    
    //对最后点击的按钮执行数字按钮事件的操作
    if (self.lastTouch)
    {
        [self performLastTouchAction];
    }
    
    //判断点击事件是否有且只有一个点击
    self.lastTouch = [touches anyObject];
    
    //更新所有按钮的高亮状态，除了点击的按钮，其他的都取消高亮
    CGPoint location = [self.lastTouch locationInView:self];
    for (ZZNumberButton *b in self.numberButtons)
    {
        if (CGRectContainsPoint(b.frame, location))
        {
            b.highlighted = YES;
        }
        else
        {
            b.highlighted = NO;
            [b zz_touchesCancelled:touches withEvent:event];
        }
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (!self.lastTouch || ![touches containsObject:self.lastTouch])
    {
        return;
    }
    
    //触摸移除后重置功能按钮的高亮状态
    CGPoint location = [self.lastTouch locationInView:self];
    if (!CGRectContainsPoint(self.clearButton.frame, location))
    {
        //禁用清除按钮的长按手势
        ZZNumberButton *clearButton = (id)self.clearButton;
        [clearButton zz_touchesCancelled:touches withEvent:event];
        _clearButtonLongPressGesture = NO;
    }
    if (!CGRectContainsPoint(self.leftButton.frame, location))
    {
        [self.leftButton zz_touchesCancelled:touches withEvent:event];
    }
    
    //更新所有按钮的高亮状态
    for (ZZNumberButton *b in self.numberButtons)
    {
        b.highlighted = CGRectContainsPoint(b.frame, location);
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (!self.lastTouch || ![touches containsObject:self.lastTouch])
    {
        return;
    }
    [self performLastTouchAction];
    self.lastTouch = nil;
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    //重置所有按钮高亮状态，清空最后点击的按钮
    self.leftButton.highlighted = NO;
    self.clearButton.highlighted = NO;
    for (ZZNumberButton *b in self.numberButtons)
    {
        b.highlighted = NO;
    }
    self.lastTouch = nil;
}

- (void)performLastTouchAction
{
    //重置所有按钮高亮状态
    CGPoint location = [self.lastTouch locationInView:self];
    for (ZZNumberButton *b in self.numberButtons)
    {
        b.highlighted = NO;
        if (CGRectContainsPoint(b.frame, location))
        {
            [self numberButtonAction:b];
        }
    }
}



#pragma mark - Left function button
- (UIButton *)rigthFunctionButton
{
    return self.leftButton;
}



#pragma mark - Actions
- (void)numberButtonAction:(UIButton *)sender
{
    if (!self.textInput) {
        return;
    }
    
    NSString *text = sender.currentTitle;
    if (_delegateFlags.textInputSupportsShouldChangeTextInRange)
    {
        if ([self.textInput shouldChangeTextInRange:self.textInput.selectedTextRange
                                    replacementText:text])
        {
            [self.textInput insertText:text];
        }
    }
    else if (_delegateFlags.delegateSupportsTextFieldShouldChangeCharactersInRange)
    {
        NSRange selectedRange = [[self class] selectedRange:self.textInput];
        UITextField *textField = (UITextField *)self.textInput;
        if ([textField.delegate textField:textField
            shouldChangeCharactersInRange:selectedRange
                        replacementString:text])
        {
            [self.textInput insertText:text];
        }
    }
    else if (_delegateFlags.delegateSupportsTextViewShouldChangeTextInRange)
    {
        NSRange selectedRange = [[self class] selectedRange:self.textInput];
        UITextView *textView = (UITextView *)self.textInput;
        if ([textView.delegate textView:textView
                shouldChangeTextInRange:selectedRange
                        replacementText:text])
        {
            [self.textInput insertText:text];
        }
    }
    else
    {
        [self.textInput insertText:text];
    }
}

- (void)clearButtonAction
{
    if (!self.textInput)
    {
        return;
    }
    
    if (_delegateFlags.textInputSupportsShouldChangeTextInRange)
    {
        UITextRange *textRange = self.textInput.selectedTextRange;
        if ([textRange.start isEqual:textRange.end])
        {
            UITextPosition *newStart = nil;
            newStart = [self.textInput positionFromPosition:textRange.start
                                                inDirection:UITextLayoutDirectionLeft
                                                     offset:1];
            textRange = [self.textInput textRangeFromPosition:newStart
                                                   toPosition:textRange.end];
        }
        if ([self.textInput shouldChangeTextInRange:textRange
                                    replacementText:@""])
        {
            [self.textInput deleteBackward];
        }
    }
    else if (_delegateFlags.delegateSupportsTextFieldShouldChangeCharactersInRange)
    {
        NSRange selectedRange = [[self class] selectedRange:self.textInput];
        if (selectedRange.length == 0 && selectedRange.location > 0)
        {
            selectedRange.location--;
            selectedRange.length = 1;
        }
        UITextField *textField = (UITextField *)self.textInput;
        if ([textField.delegate textField:textField
            shouldChangeCharactersInRange:selectedRange
                        replacementString:@""])
        {
            [self.textInput deleteBackward];
        }
    }
    else if (_delegateFlags.delegateSupportsTextViewShouldChangeTextInRange)
    {
        NSRange selectedRange = [[self class] selectedRange:self.textInput];
        if (selectedRange.length == 0 && selectedRange.location > 0)
        {
            selectedRange.location--;
            selectedRange.length = 1;
        }
        UITextView *textView = (UITextView *)self.textInput;
        if ([textView.delegate textView:textView
                shouldChangeTextInRange:selectedRange
                        replacementText:@""])
        {
            [self.textInput deleteBackward];
        }
    }
    else
    {
        [self.textInput deleteBackward];
    }
}

- (void)functionButtonAction:(id)sender
{
    if (!self.textInput)
    {
        return;
    }
    
    SEL selector = @selector(numberPad:functionButton:textInput:);
    if ([self.delegate respondsToSelector:selector])
    {
        [self.delegate numberPad:self
                  functionButton:sender
                       textInput:self.textInput];
    }
}



#pragma mark - Clear button long press
- (void)longPressGestureRecognizerAction:(UILongPressGestureRecognizer *)gestureRecognizer
{
    if (gestureRecognizer.state == UIGestureRecognizerStateBegan)
    {
        _clearButtonLongPressGesture = YES;
        [self clearButtonActionLongPress];
    }
    else if (gestureRecognizer.state == UIGestureRecognizerStateEnded)
    {
        _clearButtonLongPressGesture = NO;
    }
}

- (void)clearButtonActionLongPress
{
    if (_clearButtonLongPressGesture)
    {
        if ([self.textInput hasText])
        {
            [[UIDevice currentDevice] playInputClick];
            
            [self clearButtonAction];
            [self performSelector:@selector(clearButtonActionLongPress)
                       withObject:nil
                       afterDelay:0.1f];
        }
        else
        {
            _clearButtonLongPressGesture = NO;
        }
    }
}



#pragma mark - UIInputViewAudioFeedback
- (BOOL)enableInputClicksWhenVisible
{
    return YES;
}



#pragma mark - Additions
+ (NSRange)selectedRange:(id<UITextInput>)textInput
{
    NSInteger startOffset,endOffset;
    UITextRange *textRange = [textInput selectedTextRange];
    startOffset = [textInput offsetFromPosition:textInput.beginningOfDocument
                                     toPosition:textRange.start];
    endOffset = [textInput offsetFromPosition:textInput.beginningOfDocument
                                   toPosition:textRange.end];
    return NSMakeRange(startOffset, endOffset - startOffset);
}



#pragma mark - Button fabric
- (ZZNumberButton *)numberButton:(int)number
{
    ZZNumberButton *button = nil;
    UIColor *nColor = [[self class] numberButtonBackgroundColor];
    UIColor *hColor = [[self class] numberButtonHighlightedColor];
    button = [ZZNumberButton buttonWithBackgroundColor:nColor
                                      highlightedColor:hColor];
    [button setTitleColor:[[self class] numberButtonTextColor]
                 forState:UIControlStateNormal];
    button.titleLabel.font = [[self class] numberButtonFont];
    [button setTitle:[NSString stringWithFormat:@"%d", number]
            forState:UIControlStateNormal];
    return button;
}

- (ZZNumberButton *)clearNumButton
{
    ZZNumberButton *button = nil;
    UIColor *nColor = [[self class] clearButtonBackgroundColor];
    UIColor *hColor = [[self class] clearButtonHighlightedColor];
    button = [ZZNumberButton buttonWithBackgroundColor:nColor
                                      highlightedColor:hColor];
    button.exclusiveTouch = YES;
    return button;
}

- (ZZNumberButton *)functionButton
{
    ZZNumberButton *button = nil;
    UIColor *nColor = [[self class] functionButtonBackgroundColor];
    UIColor *hColor = [[self class] functionButtonHighlightedColor];
    button = [ZZNumberButton buttonWithBackgroundColor:nColor
                                      highlightedColor:hColor];
    button.exclusiveTouch = YES;
    return button;
}



#pragma mark - APNumberPadDefaultStyle Method
+ (CGFloat)separator
{
    //按钮间的分割线
    return [UIScreen mainScreen].scale == 2.f ? 0.5f : 1.f;
}

+ (CGRect)numberPadFrame
{
    //键盘的大小
    return CGRectMake(0.f, 0.f, 320.f, 216.f);
}

+ (UIColor *)numberPadBackgroundColor
{
    //键盘的背景颜色
    return APNPRGBA(183, 186, 191, 1.f);
}

+ (UIFont *)functionButtonFont
{
    //功能按钮的字体大小
    return [UIFont fontWithName:@"HelveticaNeue-Light" size:20.f];
}

+ (UIColor *)functionButtonTextColor
{
    //功能按钮的标题颜色
    return [UIColor whiteColor];
}

+ (UIColor *)functionButtonBackgroundColor
{
    //功能按钮的背景颜色
    return APNPRGBA(65, 105, 225, 1.f);
}

+ (UIColor *)functionButtonHighlightedColor
{
    //功能按钮的高亮颜色
    return APNPRGBA(61, 89, 171, 1.f);
}

+ (UIColor *)clearButtonBackgroundColor
{
    //清除按钮的背景颜色
    return APNPRGBA(188, 192, 198, 1.f);
}

+ (UIColor *)clearButtonHighlightedColor
{
    //清除按钮的高亮颜色
    return APNPRGBA(252, 252, 252, 1.f);
}

+ (UIColor *)numberButtonBackgroundColor
{
    //数字按钮的背景颜色
    return APNPRGBA(252, 252, 252, 1.f);
}

+ (UIColor *)numberButtonHighlightedColor
{
    //数字按钮的高亮颜色
    return APNPRGBA(188, 192, 198, 1.f);
}

+ (UIColor *)numberButtonTextColor
{
    //数字按钮的标题颜色
    return [UIColor blackColor];
}

+ (UIFont *)numberButtonFont
{
    //数字按钮的字体大小
    return [UIFont fontWithName:@"HelveticaNeue-Light" size:28.f];
}

+ (UIImage *)clearFunctionButtonImage
{
    //清除按钮的icon图片
    NSString *imageName = nil;
    imageName = @"apnumberpad_backspace_icon.png";
    return [UIImage imageNamed:imageName];
}


@end
