//
//  ZZNumberKeypad.h
//  iapppaytest
//
//  Created by 邹壮壮 on 2017/3/17.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ZZNumberKeypad;
@protocol ZZNumberKeypadDelegate <NSObject>

@optional

- (void)numberPad:(ZZNumberKeypad *)numberPad
   functionButton:(UIButton *)functionButton
        textInput:(UIResponder<UITextInput> *)textInput;

@end
@interface ZZNumberKeypad : UIView <UIInputViewAudioFeedback>
+ (instancetype)numberPadWithDelegate:(id<ZZNumberKeypadDelegate>)delegate;

/**
 *  right function button for custom configuration
     默认清除功能,若实现其他功能请重写按钮的实现方法
 */
@property (strong, readonly, nonatomic) UIButton *rigthFunctionButton;

/**
 *  left function button
 */
@property (strong, readwrite, nonatomic) UIButton *clearButton;


@end
