//
//  ZZNumberButton.h
//  iapppaytest
//
//  Created by 邹壮壮 on 2017/3/17.
//  Copyright © 2017年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZNumberButton : UIButton
+ (instancetype)buttonWithBackgroundColor:(UIColor *)backgroundColor
                         highlightedColor:(UIColor *)highlightedColor;

- (instancetype)initWithBackgroundColor:(UIColor *)backgroundColor
                       highlightedColor:(UIColor *)highlightedColor;

- (void)zz_touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event;
@end
