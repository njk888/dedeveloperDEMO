//
//  AiPayWebView.h
//  H5WebViewDemo
//
//  Created by Shixiong on 2017/3/2.
//  Copyright © 2017年 Shixiong. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol AiPayWebViewDelegate <NSObject>

@optional
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType;
- (void)webViewDidStartLoad:(UIWebView *)webView;
- (void)webViewDidFinishLoad:(UIWebView *)webView;
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error;

@end


@interface AiPayWebView : UIWebView

/**
 *  需实现代理对象
 */
@property (nonatomic, assign) id<AiPayWebViewDelegate> webViewDelegate;


/**
 *  链接使用OpenURL方法后的回调
 */
@property (nonatomic, copy) void(^openComplete)(NSString *string,BOOL status);


@end

