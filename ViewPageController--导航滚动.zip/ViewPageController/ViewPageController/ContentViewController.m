//
//  ContentViewController.m
//  ICViewPager
//
//  Created by zou145688 on 15/9/20.
//  Copyright (c) 2015 zou145688. All rights reserved.
//

#import "ContentViewController.h"

@interface ContentViewController ()

@end

@implementation ContentViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    _label = [[UILabel alloc]initWithFrame:CGRectMake(50, 120, 200, 30)];
    [self.view addSubview:_label];
   _label.text = _labelString;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
