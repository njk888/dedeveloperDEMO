//
//  HostViewController.h
//  ICViewPager
//
//  Created by zou145688 on 15/9/20.
//  Copyright (c) 2015 zou145688. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>

#import "ViewPagerController.h"

@interface HostViewController : ViewPagerController
@property (nonatomic, strong)NSArray *arrButtons;
@end
