//
//  HostViewController.m
//  ICViewPager
//
//  Created by zou145688 on 15/9/20.
//  Copyright (c) 2015 zou145688. All rights reserved.
//

#import "HostViewController.h"
#import "ContentViewController.h"

@interface HostViewController () <ViewPagerDataSource, ViewPagerDelegate>
{
    NSArray *arr;
}
@end

@implementation HostViewController

- (void)viewDidLoad {
    
    self.dataSource = self;
    self.delegate = self;
    
    self.title = @"View Pager";
    NSDictionary *dic1 = @{@"buttonID":@"1238",
                           @"title":@"美食"
                           };
    NSDictionary *dic2 = @{@"buttonID":@"2ac",
                           @"title":@"历史"
                           };
    NSDictionary *dic3 = @{@"buttonID":@"asc3",
                           @"title":@"政治"
                           };
    NSDictionary *dic4 = @{@"buttonID":@"ac4",
                           @"title":@"物理"
                           };
    NSDictionary *dic5 = @{@"buttonID":@"sv5",
                           @"title":@"化学"
                           };
    NSDictionary *dic6 = @{@"buttonID":@"6av",
                           @"title":@"地理"
                           };
    NSDictionary *dic7 = @{@"buttonID":@"br7",
                           @"title":@"美女"
                           };
    NSDictionary *dic8 = @{@"buttonID":@"8vsv",
                           @"title":@"新闻"
                           };
    arr  = @[dic1,dic2,dic3,dic4,dic5,dic6,dic7,dic8];
    // Keeps tab bar below navigation bar on iOS 7.0+
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - ViewPagerDataSource
- (NSUInteger)numberOfTabsForViewPager:(ViewPagerController *)viewPager {
    return arr.count;
}
- (UIView *)viewPager:(ViewPagerController *)viewPager viewForTabAtIndex:(NSUInteger)index {
    
    UILabel *label = [UILabel new];
    label.backgroundColor = [UIColor clearColor];
    label.font = [UIFont systemFontOfSize:13.0];
    NSDictionary *dic = [arr objectAtIndex:index];
    NSString *labText = [dic objectForKey:@"title"];
    label.text = [NSString stringWithFormat:@"%@", labText];
    label.textAlignment = NSTextAlignmentCenter;
    
    label.textColor = [UIColor redColor];
    [label sizeToFit];
    
    return label;
}

- (UIViewController *)viewPager:(ViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index {
    
    ContentViewController *cvc = [[ContentViewController alloc]init];
    NSDictionary *dic = [arr objectAtIndex:index];
    NSString *convStr = [dic objectForKey:@"buttonID"];
    cvc.labelString = [NSString stringWithFormat:@"点击:%@button", convStr];
    return cvc;
}

#pragma mark - ViewPagerDelegate
- (CGFloat)viewPager:(ViewPagerController *)viewPager valueForOption:(ViewPagerOption)option withDefault:(CGFloat)value {
    
    switch (option) {
        case ViewPagerOptionStartFromSecondTab:
            return 0.0;
            break;
        case ViewPagerOptionCenterCurrentTab:
            return 1.0;
            break;
        case ViewPagerOptionTabLocation:
            return 1.0;
            break;
        default:
            break;
    }
    
    return value;
}
- (UIColor *)viewPager:(ViewPagerController *)viewPager colorForComponent:(ViewPagerComponent)component withDefault:(UIColor *)color {
    
    switch (component) {
        case ViewPagerIndicator:
            return [UIColor blueColor] ;
            break;
            case ViewPagerTabsView:
            //return [UIColor blackColor];
            break;
            case ViewPagerContent:
            return [UIColor grayColor];
            break;
        default:
            break;
    }
    
    return color;
}

@end
