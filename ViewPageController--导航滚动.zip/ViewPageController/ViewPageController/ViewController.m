//
//  ViewController.m
//  ViewPageController
//
//  Created by zou145688 on 15/9/20.
//  Copyright (c) 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"
#import "HostViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    HostViewController *host = [[HostViewController alloc]init];
    host.view.frame = CGRectMake(0, 64.f, self.view.frame.size.width, self.view.frame.size.height);
    
    [self.view addSubview:host.view];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
