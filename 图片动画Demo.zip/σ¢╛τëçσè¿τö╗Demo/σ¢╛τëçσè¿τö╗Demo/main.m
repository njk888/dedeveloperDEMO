//
//  main.m
//  图片动画Demo
//
//  Created by 肖坚伟 on 2016/10/17.
//  Copyright © 2016年 轻舟. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
