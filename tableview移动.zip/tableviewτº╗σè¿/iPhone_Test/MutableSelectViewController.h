//
//  MutableSelectViewController.h
//  iPhone_Test
//
//  Created by gft  on 12-12-5.
//  Copyright (c) 2012年 cofortune. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MutableSelectViewController : UITableViewController

@property (retain, nonatomic) NSMutableArray *items;

@end
