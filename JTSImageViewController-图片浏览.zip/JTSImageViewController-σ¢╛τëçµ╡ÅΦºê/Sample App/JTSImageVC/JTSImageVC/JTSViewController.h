//
//  JTSViewController.h
//  JTSImageVC
//
//  Created by Jared on 3/29/14.
//  Copyright (c) 2014 Nice Boy, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JTSViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *bigImageButton;

@end
