//
//  ViewController.m
//  PictureScrollView
//
//  Created by 邹壮壮 on 2016/12/15.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "ViewController.h"
#import "ZZPictureScrollView.h"

#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    ZZPictureScrollView *wsRoll = [[ZZPictureScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    wsRoll.backgroundColor = [UIColor whiteColor];
    wsRoll.timeInterval = 0.01; //移动一次需要的时间
    wsRoll.rollSpace = 0.5; //每次移动的像素距离
       wsRoll.localImage = [UIImage imageNamed:@"111.jpg"];//本地图片
  // wsRoll.netImageURL = @"http://jiangsu.china.com.cn/uploadfile/2016/0122/1453449251090847.jpg"; //网络图片地址
    [wsRoll startRoll]; //开始滚动
    [self.view addSubview:wsRoll];
    
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
