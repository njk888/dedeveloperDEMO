//
//  ZZPictureScrollView.h
//  PictureScrollView
//
//  Created by 邹壮壮 on 2016/12/15.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ZZPictureScrollView : UIView
/**
 本地图片
 */
@property(nonatomic,strong)UIImage *localImage;
/**
 网络图片URL
 */
@property(nonatomic,strong)NSString *netImageURL;

/**
 滚动的时间间隔,是每次滚动的距离需要的时间，设置越小，移动越快。默认是0.05秒
 */
@property(nonatomic,assign)CGFloat timeInterval;
/**
 每次滚动的距离 默认为1个像素
 */
@property(nonatomic,assign)CGFloat rollSpace;
/**
 *  开始滚动
 */
- (void)startRoll;

@end
