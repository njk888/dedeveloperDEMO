# LXSegmentControllerDemo
####仿网易新闻等各种样式的顶部标题切换界面控制器####

可实现网易新闻等顶部标签切换界面样式, 与常见控件区别是, 一般的此类控件只支持传入文字, 且不能定制标题栏宽高等  
这个控件还可以传入View作为顶部标签, 实现一些特殊样式的顶部标签, 如下图
![image1](https://github.com/CoderLXWang/LXSegmentControllerDemo/blob/master/LXSegmentControllerDemo/image1.png)

#####其他支持样式:
######网易新闻标题+下标样式 
![image1](https://github.com/CoderLXWang/LXSegmentControllerDemo/blob/master/LXSegmentControllerDemo/image2.png)

######标题+覆盖
![image1](https://github.com/CoderLXWang/LXSegmentControllerDemo/blob/master/LXSegmentControllerDemo/image3.png)
![image1](https://github.com/CoderLXWang/LXSegmentControllerDemo/blob/master/LXSegmentControllerDemo/image4.png)

######标题+下划线 (定宽定高)  
![image1](https://github.com/CoderLXWang/LXSegmentControllerDemo/blob/master/LXSegmentControllerDemo/image5.png)
