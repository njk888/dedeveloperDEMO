//
//  ViewController.h
//  LXSegmentControllerDemo
//
//  Created by sharejoy_lx on 16-06-08.
//  Copyright © 2016年 shangbin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LXSegmentController.h"

@interface ViewController : LXSegmentController


@end

