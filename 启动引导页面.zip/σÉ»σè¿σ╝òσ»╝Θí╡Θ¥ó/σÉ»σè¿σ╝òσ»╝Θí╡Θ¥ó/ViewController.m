//
//  ViewController.m
//  启动引导页面
//
//  Created by zou145688 on 15/11/2.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"
#import "StartGuidView.h"
@interface ViewController ()<StartGuidViewDelegate>
@property (nonatomic, strong) StartGuidView *startGuidView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if (![defaults objectForKey:@"frist_start_app"]) {
        self.startGuidView = [[StartGuidView alloc]initWithFrame:self.view.frame];
        self.startGuidView.delegate = self;
        self.startGuidView.backgroundColor = [UIColor colorWithWhite:0.149 alpha:1.000];
        [self.view addSubview:self.startGuidView];
    }else{
        
    }
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)onDoneButtonPressed{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:@"YES" forKey:@"frist_start_app"];
    [defaults synchronize];
[UIView animateWithDuration:1.f delay:0 options:UIViewAnimationOptionAllowAnimatedContent animations:^{
    self.startGuidView.alpha = 0;
} completion:^(BOOL finished) {
    [self.startGuidView removeFromSuperview];
}];
    }
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
