//
//  ViewController.h
//  XHLaunchAdExample
//
//  Created by xiaohui on 16/6/11.
//  Copyright © 2016年 qiantou. All rights reserved.
//  代码地址:https://github.com/CoderZhuXH/XHLaunchAd

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
