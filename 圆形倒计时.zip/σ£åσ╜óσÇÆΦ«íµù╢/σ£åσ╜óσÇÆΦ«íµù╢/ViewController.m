//
//  ViewController.m
//  圆形倒计时
//
//  Created by zou145688 on 15/10/12.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    C_circularProgressBar = [[CircularProgressBar alloc]initWithFrame:self.view.bounds];
    C_circularProgressBar.delegate = self;
//    一秒为初始时间
    [C_circularProgressBar setTotalSecondTime:10];
//    一分钟为初始时间
//    [C_circularProgressBar setTotalMinuteTime:0.1];
    [self.view addSubview:C_circularProgressBar];
    
    UITapGestureRecognizer *tapO = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(singleTapO)];
    tapO.numberOfTapsRequired = 1;
    [C_circularProgressBar setUserInteractionEnabled:YES];
    [C_circularProgressBar addGestureRecognizer:tapO];
    
    UITapGestureRecognizer *tapT = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(singletapT)];
    tapT.numberOfTapsRequired = 2;
    [C_circularProgressBar addGestureRecognizer:tapT];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)singleTapO{

//    [customAlert show];
     [C_circularProgressBar startTimer];
}
- (void)singletapT{
    [C_circularProgressBar pauseTimer];
}
- (void)CircularProgressEnd{
    [C_circularProgressBar stopTimer];
    [C_circularProgressBar setTotalMinuteTime:0];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
