//
//  TimeHelper.h
//  CircularProgressBar
//
//  Created by du on 10/8/15.
//  Copyright © 2015 du. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface TimeHelper : NSObject

+ (NSString *)formatTimeWithSecond:(CGFloat)left_time;

@end
