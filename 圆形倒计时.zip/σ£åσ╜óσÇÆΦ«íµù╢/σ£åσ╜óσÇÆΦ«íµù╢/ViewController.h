//
//  ViewController.h
//  圆形倒计时
//
//  Created by zou145688 on 15/10/12.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CircularProgressBar.h"

@interface ViewController : UIViewController<CircularProgressDelegate>
{
    CircularProgressBar *C_circularProgressBar;
    NSTimer *C_timer;
    int C_timeSelected;
}

@end

