//
//  CaptureViewController.h
//  SBVideoCaptureDemo
//
//  Created by Pandara on 14-8-12.
//  Copyright (c) 2014年 Pandara. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "SBCaptureDefine.h"
#import "SBVideoRecorder.h"

@interface CaptureViewController : UIViewController <SBVideoRecorderDelegate, UIAlertViewDelegate>

@end
