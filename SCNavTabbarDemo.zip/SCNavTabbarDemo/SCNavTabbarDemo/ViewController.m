//
//  ViewController.m
//  SCNavTabbarDemo
//
//  Created by zou145688 on 15/11/17.
//  Copyright (c) 2015年 SCNavTabbarDemo. All rights reserved.
//

#import "ViewController.h"
#import "SCNavTabBar.h"

#import "Header.h"
@interface ViewController ()<UIScrollViewDelegate, SCNavTabBarDelegate>

@property (nonatomic, assign)NSInteger  currentIndex;
@property (nonatomic, strong)SCNavTabBar  *navTabBar;
@property (nonatomic, strong)NSArray *arr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden = YES;
    // Do any additional setup after loading the view, typically from a nib.
     _arr = [[NSArray alloc]init];
    NSDictionary *dic1 = @{@"buttonID":@"1",
                           @"title":@"美食"
                           };
    NSDictionary *dic2 = @{@"buttonID":@"2",
                           @"title":@"历史"
                           };
    NSDictionary *dic3 = @{@"buttonID":@"3",
                           @"title":@"政治"
                           };
    NSDictionary *dic4 = @{@"buttonID":@"4",
                           @"title":@"物理"
                           };
    NSDictionary *dic5 = @{@"buttonID":@"5",
                           @"title":@"化学"
                           };
    NSDictionary *dic6 = @{@"buttonID":@"6",
                           @"title":@"地理"
                           };
    NSDictionary *dic7 = @{@"buttonID":@"7",
                           @"title":@"美女"
                           };
    NSDictionary *dic8 = @{@"buttonID":@"8",
                           @"title":@"新闻"
                           };
    _arr  = @[dic1,dic2,dic3,dic4,dic5,dic6,dic7,dic8];
    [self viewInit];
}
- (void)viewInit{
    _navTabBar = [[SCNavTabBar alloc] initWithFrame:CGRectMake(DOT_COORDINATE, 64.f, SCREEN_WIDTH, NAV_TAB_BAR_HEIGHT) showArrowButton:YES];
    _navTabBar.delegate = self;
    _navTabBar.backgroundColor = [UIColor whiteColor];
    //_navTabBar.itemTitles = _arr;
    [_navTabBar updateData:_arr];
    [self.view addSubview:_navTabBar];
}
- (void)itemDidSelectedWithIndex:(NSInteger)index buttonId:(NSString *)buttonId{
    _navTabBar.currentItemIndex = index;
    NSLog(@"在这里进行网络请求%@",buttonId);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end


