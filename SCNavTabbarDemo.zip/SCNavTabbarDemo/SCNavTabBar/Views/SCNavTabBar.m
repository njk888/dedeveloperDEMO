//
//  SCNavTabBar.m
//  SCNavTabBarController
//
//  Created by zou145688 on 15/7/17.
//  Copyright (c) 2015年 SCNavTabBarController. All rights reserved.
//

#import "SCNavTabBar.h"
//#import "CommonMacro.h"
#import "Header.h"

@interface SCNavTabBar ()
{
    UIScrollView    *_navgationTabBar;
    UIImageView     *_arrowButton;
    
    UIView          *_line;
    
    NSMutableArray  *_items;
    NSArray         *_itemsWidth;
    BOOL            _showArrowButton;
    BOOL            _popItemMenu;
}

@end

@implementation SCNavTabBar

- (id)initWithFrame:(CGRect)frame showArrowButton:(BOOL)show
{
    self = [super initWithFrame:frame];
    if (self)
    {
        
        _showArrowButton = show;
        [self viewConfig];
    }
    return self;
}

#pragma mark -
#pragma mark - Private Methods



- (void)viewConfig
{
    _items = [@[] mutableCopy];
    //CGFloat functionButtonX = _showArrowButton ? (SCREEN_WIDTH - ARROW_BUTTON_WIDTH) : SCREEN_WIDTH;
    if (_showArrowButton)
    {
        _arrowButton = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 0, 0)];
        _arrowButton.hidden = YES;
        [self addSubview:_arrowButton];
    }

    _navgationTabBar = [[UIScrollView alloc] initWithFrame:CGRectMake(DOT_COORDINATE, 0, SCREEN_WIDTH, 44)];
    _navgationTabBar.backgroundColor = [UIColor grayColor];
    _navgationTabBar.showsHorizontalScrollIndicator = NO;
    [self addSubview:_navgationTabBar];
    
}

- (void)updateData:(NSArray *)arr
{
    _itemTitles = arr;
    _itemsWidth = [self getButtonsWidthWithTitles:arr];
    if (_itemsWidth.count)
    {
        //设置scrollview的滚动范围
        CGFloat contentWidth = [self contentWidthAndAddNavTabBarItemsWithButtonsWidth:_itemsWidth];
        _navgationTabBar.contentSize = CGSizeMake(contentWidth, DOT_COORDINATE);
    }
}
- (CGFloat)contentWidthAndAddNavTabBarItemsWithButtonsWidth:(NSArray *)widths
{
    CGFloat buttonX = DOT_COORDINATE;
    for (NSInteger index = 0; index < [_itemTitles count]; index++)
    {
        NSDictionary *dic = [_itemTitles objectAtIndex:index];
        NSString *title = [dic objectForKey:@"title"];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(buttonX, 0, [widths[index] floatValue], NAV_TAB_BAR_HEIGHT);
        [button setTitle:title forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        //选中button的颜色
        [button setTitleColor:[UIColor redColor] forState:UIControlStateSelected];
        [button addTarget:self action:@selector(itemPressed:) forControlEvents:UIControlEventTouchUpInside];
        [_navgationTabBar addSubview:button];
        button.tag = 10 + index;
        [_items addObject:button];
        buttonX += [widths[index] floatValue];
    }
    
    [self showLineWithButtonWidth:[widths[0] floatValue]];
    return buttonX;
}
//初始化底部的滚动线
- (void)showLineWithButtonWidth:(CGFloat)width
{
    _line = [[UIView alloc] initWithFrame:CGRectMake(2.0f, NAV_TAB_BAR_HEIGHT - 3.0f, 30.f, 3.0f)];
    _line.backgroundColor = UIColorWithRGBA(20.0f, 80.0f, 200.0f, 0.7f);
    [_navgationTabBar addSubview:_line];
}
//默认点击的button
- (void)clickButtonAtIndex:(NSInteger)index{
    if (_items.count>0) {
        UIButton *aButton = [_items objectAtIndex:index];
        [self itemPressed:aButton];
    }
    
}
//取消所有button的选中状态
-(void)changeButtonsToNormalState{
    for (UIButton *vButton in _items) {
        vButton.selected = NO;
    }
}
- (void)itemPressed:(UIButton *)button
{
    NSString *string;
    NSInteger index = 0;
    for (NSInteger i = 0; i< _items.count; i++) {
        UIButton *aButton = [_items objectAtIndex:i];
        if (aButton.tag == button.tag) {
            NSDictionary *dic = [_itemTitles objectAtIndex:button.tag - 10];
            string = [dic objectForKey:@"buttonID"];
            index = i;
        }
    }
    [self changeButtonsToNormalState];
    button.selected = YES;
    [_delegate itemDidSelectedWithIndex:index buttonId:string];
}


//根据文字计算button的宽带
- (NSArray *)getButtonsWidthWithTitles:(NSArray *)titles;
{
    NSMutableArray *widths = [@[] mutableCopy];
    
    for (NSDictionary *titleDic in titles)
    {
        NSString *title = [titleDic objectForKey:@"title"];
        CGSize size = [title sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15]}];
        //这里的20为button的间距
        NSNumber *width = [NSNumber numberWithFloat:size.width + 20.0f];
        [widths addObject:width];
    }
    return widths;
}



#pragma mark - Public Methods

//scrollview根据点击的button滚动到相应的位置
- (void)setCurrentItemIndex:(NSInteger)currentItemIndex
{
    _currentItemIndex = currentItemIndex;
    UIButton *button = _items[currentItemIndex];
    
    CGFloat flag = _showArrowButton ? (SCREEN_WIDTH - NAV_TAB_BAR_HEIGHT) : SCREEN_WIDTH;
    if (button.frame.origin.x + button.frame.size.width > flag)
    {
        CGFloat offsetX = button.frame.origin.x + button.frame.size.width - flag;
        if (_currentItemIndex < [_itemTitles count]-1)
        {
            offsetX = offsetX + NAV_TAB_BAR_HEIGHT;
        }
        
        [_navgationTabBar setContentOffset:CGPointMake(offsetX, DOT_COORDINATE) animated:YES];
    }
    else
    {
        [_navgationTabBar setContentOffset:CGPointMake(DOT_COORDINATE, DOT_COORDINATE) animated:YES];
    }
    //底部的线也跟随移动到相应的位置
    [UIView animateWithDuration:0.2f animations:^{
        _line.frame = CGRectMake(button.frame.origin.x + 2.0f, _line.frame.origin.y, [_itemsWidth[currentItemIndex] floatValue] - 4.0f, _line.frame.size.height);
    }];
}




@end

