//
//  SCNavTabBar.h
//  SCNavTabBarController
//
//  Created by zou145688 on 15/7/17.
//  Copyright (c) 2015年 SCNavTabBarController. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SCNavTabBarDelegate <NSObject>

@optional

- (void)itemDidSelectedWithIndex:(NSInteger)index buttonId:(NSString *)buttonId;

- (void)shouldPopNavgationItemMenu:(BOOL)pop height:(CGFloat)height;

@end

@interface SCNavTabBar : UIView

@property (nonatomic, weak)     id          <SCNavTabBarDelegate>delegate;

@property (nonatomic, assign)   NSInteger   currentItemIndex;           // current selected item's index
@property (nonatomic, strong)   NSArray     *itemTitles;                // all

- (id)initWithFrame:(CGRect)frame showArrowButton:(BOOL)show;

- (void)updateData:(NSArray *)arr;

- (void)clickButtonAtIndex:(NSInteger)index;

@end

