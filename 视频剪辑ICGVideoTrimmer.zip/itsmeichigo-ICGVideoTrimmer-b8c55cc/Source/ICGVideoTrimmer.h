//
//  ICGVideoTrimmer.h
//  ICGVideoTrimmer
//
//  Created by Huong Do on 1/29/15.
//  Copyright (c) 2015 ichigo. All rights reserved.
//

#ifndef ICGVideoTrimmer_ICGVideoTrimmer_h
#define ICGVideoTrimmer_ICGVideoTrimmer_h

#import "ICGVideoTrimmerView.h"
#import "ICGThumbView.h"
#import "ICGRulerView.h"

#endif
