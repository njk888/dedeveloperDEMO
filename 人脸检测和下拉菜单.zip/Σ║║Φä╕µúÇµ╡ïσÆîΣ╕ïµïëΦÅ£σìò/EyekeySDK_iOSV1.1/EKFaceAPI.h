//
//  EKFaceAPI.h
//  EyekeyFaceSDK
//
//  Created by cocoajin on 15/1/17.
//  Copyright (c) 2015年 www.eyekey.com. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 
 使用需知
 ====================================
 ************* README ***************
 ====================================
 
 1. 先去 http://www.eyekey.com/index.html 注册app
 2. 查看详细文档 http://eyekey.com/devcenter/api/APIface.html
 
 **/


/**
 *  SDK处理完成回调block
 *
 *  @param JSON  SDK处理返回的Json数据
 *  @param error SDK处理返回的错误
 */
typedef void(^EKAPICompleteBlock)(id JSON,NSError *error);




@interface EKFaceAPI : NSObject

/**
 *  初始SDK, 请先在 http://www.eyekey.com/index.html 创建应用
 *
 *  @param appID  您的appid
 *  @param appKey 您的appkey
 */
+(void)initSDKWithAppID:(NSString *)appID appKey:(NSString *)appKey;

#pragma mark Check
/**
 *  处理指定url图片的人脸信息
 *
 *  @param imgUrl        人脸图片url
 *  @param completeBlock 回调block
 */
+ (void)checkingFaceInfoWithImgUrl:(NSString *)imgUrl complete:(EKAPICompleteBlock)completeBlock;

/**
 *  处理指定 人脸图像数据 的人脸信息
 *
 *  @param base64Data    人脸图像的base64编码数据
 *  @param completeBlock 回调block
 */
+ (void)checkingFaceInfoWithImageData:(NSString *)base64Data complete:(EKAPICompleteBlock)completeBlock;

/**
 *  检测人脸的五官信息 49点模式
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. face_id
 *  @param completeBlock 回调block
 */
+ (void)checkMarkWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;

#pragma mark Match
/**
 *  给定 Face 和 people 来判断是否为同一个人
 *
 *  @param parms         参数为字典，应包括如下参数
 *                       1. face_id;
 *                       2. poeple_id 或 people_name;
 *  @param completeBlock 回调block
 */
+ (void)matchVerifyWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  计算两个Face的相似性以及五官可信度
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. face_id1
 *                      2. face_id2
 *  @param completeBlock 回调block
 */
+ (void)matchCompareWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  向EYEKEY平台确认应用客户端获取的动态是否有效
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. dynamicode ,第三方应用获取的动态码
 *                      2. people_id 或 people_name
 *  @param completeBlock 回调block
 */
+ (void)matchConfirmWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  给定一个Face和一个Facegather，在Facegather内搜索最相似的Face
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. face_id ，待搜索的face
 *                      2. facegather_id 或 facegather_name
 *                      3. count 可选,表示获取的结果数量，默认为3个
 *  @param completeBlock 回调block
 */
+ (void)matchSearchWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  一个或多个faceid 在 Crowd中查询最相似的people
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. crowd_id 或 crowd_name
 *                      2. face_id ，如果有多个，请用 逗号隔开
 *  @param completeBlock 回调block
 */
+ (void)matchIdentifyWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


#pragma mark People
/**
 *  创建一个People,一个People 最多允许包含50个Face,开发版最多允许创建100个people
 *
 *  @param parms         参数为字典，应包括如下参数
 *                      1. people_name , (可选) 必须在全局App中唯一，建议以com.xxx.xx标识
 *                      2. face_id, 如果有多个 face_id, 请用 逗号 隔开组成字符串
 *                      3. corwd_id 或 crowd_name; 如果有多个请用 逗号隔开
 *                      4. tip 简单说明
 *  @param completeBlock 回调block
 */
+ (void)peopleCreateWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;

/**
 *  将一组Face 添加到 一个 people中，注意 一个 Face 只能被加入到一个People中
 *
 *  @param parms         参数为字典，应包括如下参数
 *                      1. people_name 或 people_id
 *                      2. face_id , 如果有多个，请用 逗号 隔开
 *  @param completeBlock 回调block
 */
+ (void)peopleAddWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  删除一个或一组 people
 *
 *  @param parms         参数为字典，应包括如下参数
 *                      1. people_name 或 people_id,如果有多个，请用逗号隔开
 *  @param completeBlock 回调block
 */
+ (void)peopleDeleteWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  删除people中的一个或多个Face
 *
 *  @param parms         参数为字典，应包括如下参数
 *                      1. people_name 或 people_id
 *                      2. face_id ,如果有多个，请用逗号隔开 ,可指定all
 *  @param completeBlock 回调block
 */
+ (void)peopleRemoveWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  设置People在 name 和 tip
 *
 *  @param parms         参数为字典，应包括如下参数
 *                      1. people_id 或 people_name
 *                      2. name 可选 ，新的name
 *                      3. tip 新的tip
 *  @param completeBlock 回调block
 */
+ (void)peopleSetWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  获取指定 people的所有信息
 *
 *  @param parms         参数为字典，应包括如下参数
 *                      1. people_id 或 people_name
 *  @param completeBlock 回调block
 */
+ (void)peopleGetWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


#pragma mark Crowd
/**
 *  创建一个 Crowd，一个Crowd 最多允许包含 1000个people;开发版本最多允许创建5个 crowd
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. crowd_name (可选),必须在全局App中唯一，建议以 com.xxx.xx标识
 *                      2. people_id 或 people_name; 如果有多个，请用逗号隔开组合
 *                      3. tip ，简单的说明
 *  @param completeBlock 回调block
 */
+ (void)crowdCreateWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;

/**
 *  将一组people 加入到一个crowd中
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. crowd_id 或 crowd_name
 *                      2. people_id 或 people_name ,如果有多个，请使用逗号隔开
 *  @param completeBlock 回调block
 */
+ (void)crowdAddWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  删除一个或一组 crowd
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. crowd_name 或 crowd_id ，如果有多个请用 逗号隔开
 *  @param completeBlock 回调block
 */
+ (void)crowdDeleteWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  从crowd删除一个或多个people
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. crowd_id 或 crowd_name
 *                      2. people_id 或 people_name ,要删除的一个或多个people,请用 逗号隔开表示多个，可指定all
 *  @param completeBlock 回调block
 */
+ (void)crowdRemoveWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  获取一个 crowd 的详细信息
 *
 *  @param parms         参数为字典，应包含如下参数
 *                      1. crowd_id 或 crowd_name
 *  @param completeBlock 回调block
 */
+ (void)crowdGetWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;

#pragma mark faceGather

/**
 *  创建一个faceGather,一个facegather可创建10000个face,开发版本最多允许创建5个facegather
 *
 *  @param parms         参数为字典，应该包含如下参数
 *                      1. facegather_name 可选，建议为 com.xxx.xxx 标识,必须全局唯一
 *                      2. face_id ，如果有多个，请用逗号隔开
 *                      3. tip ,简单描述
 *  @param completeBlock 回调block
 */
+ (void)faceGatherCreateWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  删除一个 faceGather
 *
 *  @param parms         参数为字典，应该包含如下参数
 *                      1. facegather_name 或 facegather_id, 如果有多个，请用逗号隔开
 *  @param completeBlock 回调block
 */
+ (void)faceGatherDeleteWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  将一组face添加到 facegather中,一个face只能被添加到一个facegather中
 *
 *  @param parms         参数为字典，应该包含如下参数
 *                      1. facegather_name 或 facegather_id
 *                      2. face_id,如果有多个，请用逗号隔开
 *  @param completeBlock 回调block
 */
+ (void)faceGatherAddFaceWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


/**
 *  删除facegather中的一个或多个face
 *
 *  @param parms         参数为字典，应该包含如下参数
 *                      1. facegather_name 或 facegather_id
 *                      2. face_id，如果有多个，请用逗号隔开
 *  @param completeBlock 回调block
 */
+ (void)faceGatherRemoveWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;

/**
 *  设置facegather 在 name 或 tip
 *
 *  @param parms         参数为字典，应该包含如下参数
 *                      1. facegather_id 或 facegather_name
 *                      2. name ,新的name 可选
 *                      3. tip 新的tip
 *  @param completeBlock 回调block
 */
+ (void)faceGatherSetWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;

/**
 *  获取facegather 的相关详细信息
 *
 *  @param parms         参数为字典，应该包含如下参数
 *                      1. facegather_id 或 facegather_name
 *  @param completeBlock 回调block
 */
+ (void)faceGatherGetWithParms:(NSDictionary *)parms complete:(EKAPICompleteBlock)completeBlock;


#pragma mark app info

/**
 *  获取创建的应用的详细信息
 *
 *  @param completeBlock 回调block
 */
+ (void)getAppInfoComplete:(EKAPICompleteBlock)completeBlock;

#pragma mark else tools

/**
 *  是否开启debug模式，将打印log,默认是YES
 *
 *  @param isLog 是否开启log输出
 */
+ (void)debugLog:(BOOL)isLog;


/**
 *  获取当前SDK的发布版本号
 *
 *  @return 发布版本号
 */
+ (NSString *)SDKVersion;

/**
 *  获取当前SDK的build号
 *
 *  @return build版本号
 */
+ (NSString *)SDKBuildVersion;


@end
