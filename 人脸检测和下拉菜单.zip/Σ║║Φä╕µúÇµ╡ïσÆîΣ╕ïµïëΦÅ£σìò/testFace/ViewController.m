//
//  ViewController.m
//  testFace
//
//  Created by 邹壮壮 on 16/8/26.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "ViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "EKFaceAPI.h"
#import "DropDownMenu.h"

#import "AWCollectionViewDialLayout.h"
typedef void (^block)(id JSON,NSError *error);

@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,DrSuperMenuDataSource, DrSuperMenuDelegate,UICollectionViewDataSource,UICollectionViewDelegate>
{
    NSMutableDictionary *thumbnailCache;
    BOOL showingSettings;
    UIView *settingsView;
    
    UILabel *radiusLabel;
    UISlider *radiusSlider;
    UILabel *angularSpacingLabel;
    UISlider *angularSpacingSlider;
    UILabel *xOffsetLabel;
    UISlider *xOffsetSlider;
    UISegmentedControl *exampleSwitch;
    AWCollectionViewDialLayout *dialLayout;
    CGFloat cell_height;
    
    int type;
}
@property (weak, nonatomic) IBOutlet UILabel *contentLable;
@property (weak, nonatomic) IBOutlet UITextView *content;

@property (nonatomic, strong) DropDownMenu *menu;

@property (nonatomic, strong) NSArray *sort;
@property (nonatomic, strong) NSArray *choose;
@property (nonatomic, strong) NSArray *classify;
@property (nonatomic, strong) NSArray *jiachang;
@property (nonatomic, strong) NSArray *difang;
@property (nonatomic, strong) NSArray *tese;
@property (nonatomic, strong) NSArray *rihan;
@property (nonatomic, strong) NSArray *xishi;
@property (nonatomic, strong) NSArray *shaokao;
@end

static NSString *cellId = @"cellId";
static NSString *cellId2 = @"cellId2";

@implementation ViewController
@synthesize collectionView, items,editBtn;
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setMenu];
    [self setCollection];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self createPeople:nil];
}
- (void)createPeople:(NSString *)name{
    NSDictionary *params = [NSDictionary dictionaryWithObject:@"test" forKey:@"people_name"];
    [EKFaceAPI peopleCreateWithParms:params complete:^(id JSON, NSError *error) {
        
    }];
}
- (void)setMenu{
    self.classify = @[@"全部", @"新店特惠", @"连锁餐厅", @"家常快餐", @"地方菜", @"特色小吃", @"日韩料理", @"西式快餐", @"烧烤海鲜"];
    self.sort = @[@"People", @"people_create", @"people_delete", @"people_add", @"people_remove", @"people_set", @"people_get"];
    self.choose = @[@"匹配",@"match_compare", @"match_verify", @"match_confirm", @"match_search", @"match_identify"];
    self.jiachang = @[@"People", @"黄焖J8饭", @"麻辣烫", @"盖饭"];
    self.difang = @[@"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜"];
    self.tese = @[@"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜"];
    self.rihan = @[@"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜"];
    self.xishi = @[@"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜"];
    self.shaokao = @[@"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜", @"湘菜"];
    
    
    _menu = [[DropDownMenu alloc] initWithOrigin:CGPointMake(0, 64) andHeight:44];
    _menu.delegate = self;
    _menu.dataSource = self;
    [self.view addSubview:_menu];
    
    [_menu selectDeafultIndexPath];
}
- (void)setCollection{
    type = 0;
    showingSettings = NO;
    
    
    [collectionView registerNib:[UINib nibWithNibName:@"dialCell" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:cellId];
    [collectionView registerNib:[UINib nibWithNibName:@"dialCell2" bundle:[NSBundle mainBundle]] forCellWithReuseIdentifier:cellId2];
    
    
    NSError *error;
    NSString *jsonPath = [[NSBundle mainBundle] pathForResource:@"photos" ofType:@"json"];
    NSString *jsonString = [[NSString alloc] initWithContentsOfFile:jsonPath encoding:NSUTF8StringEncoding error:NULL];
    NSLog(@"jsonString:%@",jsonString);
    items = [NSJSONSerialization JSONObjectWithData:[jsonString dataUsingEncoding:NSUTF8StringEncoding] options:kNilOptions error:&error];
    
    settingsView = [[UIView alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, self.view.frame.size.height-44)];
    [settingsView setBackgroundColor:[UIColor colorWithWhite:0.0 alpha:0.4]];
    [self.view addSubview:settingsView];
    [self buildSettings];
    
    
    CGFloat radius = radiusSlider.value * 1000;
    CGFloat angularSpacing = angularSpacingSlider.value * 90;
    CGFloat xOffset = xOffsetSlider.value * 320;
    CGFloat cell_width = 240;
    cell_height = 100;
    [radiusLabel setText:[NSString stringWithFormat:@"Radius: %i", (int)radius]];
    [angularSpacingLabel setText:[NSString stringWithFormat:@"Angular spacing: %i", (int)angularSpacing]];
    [xOffsetLabel setText:[NSString stringWithFormat:@"X offset: %i", (int)xOffset]];
    
    
    dialLayout = [[AWCollectionViewDialLayout alloc] initWithRadius:radius andAngularSpacing:angularSpacing andCellSize:CGSizeMake(cell_width, cell_height) andAlignment:WHEELALIGNMENTCENTER andItemHeight:cell_height andXOffset:xOffset];
    [dialLayout setShouldSnap:YES];
    [collectionView setCollectionViewLayout:dialLayout];
    collectionView.dataSource = self;
    collectionView.delegate = self;
    dialLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    [editBtn setTarget:self];
    [editBtn setAction:@selector(toggleSettingsView)];
    
    [self switchExample];
}
- (IBAction)selectImage:(id)sender {
    UIAlertController *c=[[UIAlertController alloc]init];
    [c addAction:[UIAlertAction actionWithTitle:@"手机拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self takePhoto];
        
    }]];
    [c addAction:[UIAlertAction actionWithTitle:@"从相册选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self retriveingPhotoFromLibrary];
    }]];
    [c addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    
    [self presentViewController:c animated:YES completion:nil];
}
- (void)takePhoto{
    
    if ([self isCameraAvailable] &&
        [self doesCameraSupportTakingPhotos]){
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.allowsEditing = YES;
        controller.sourceType = UIImagePickerControllerSourceTypeCamera;
        NSString *requiredMediaType = (NSString *)kUTTypeImage;
        controller.mediaTypes = [[NSArray alloc]
                                 initWithObjects:requiredMediaType, nil];
        controller.allowsEditing = YES;
        controller.delegate = self;
        [self presentViewController:controller animated:YES completion:nil];
    }else{
        NSLog(@"Camera is not available.");
    }
}
- (void)retriveingPhotoFromLibrary{
    if ([self isPhotoLibraryAvailable]){ UIImagePickerController *controller =
        [[UIImagePickerController alloc] init];
        controller.allowsEditing = YES;
        controller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary; NSMutableArray *mediaTypes = [[NSMutableArray alloc] init];
        if ([self canUserPickPhotosFromPhotoLibrary]){
            [mediaTypes addObject:(__bridge NSString *)kUTTypeImage];
        }
        controller.mediaTypes = mediaTypes;
        controller.delegate = self;
        [self presentViewController:controller animated:YES completion:nil];
    }
}

#pragma mark - Device ability

- (BOOL) isCameraAvailable{
    return [UIImagePickerController isSourceTypeAvailable:
            UIImagePickerControllerSourceTypeCamera];
}

- (BOOL) doesCameraSupportTakingPhotos{
    return [self cameraSupportsMedia:(__bridge NSString *)kUTTypeImage sourceType:UIImagePickerControllerSourceTypeCamera];
}
- (BOOL) isPhotoLibraryAvailable{
    return [UIImagePickerController isSourceTypeAvailable:
            UIImagePickerControllerSourceTypePhotoLibrary];
}

- (BOOL) canUserPickPhotosFromPhotoLibrary{
    return [self
            cameraSupportsMedia:(__bridge NSString *)kUTTypeImage sourceType:UIImagePickerControllerSourceTypePhotoLibrary];
}

- (BOOL) cameraSupportsMedia:(NSString *)paramMediaType sourceType:(UIImagePickerControllerSourceType)paramSourceType{
    __block BOOL result = NO;
    if ([paramMediaType length] == 0){ NSLog(@"Media type is empty."); return NO;
    }
    NSArray *availableMediaTypes =
    [UIImagePickerController
     availableMediaTypesForSourceType:paramSourceType];
    [availableMediaTypes enumerateObjectsUsingBlock:
     ^(id obj, NSUInteger idx, BOOL *stop) {
         NSString *mediaType = (NSString *)obj;
         if ([mediaType isEqualToString:paramMediaType]){
             result = YES;
             *stop= YES; }
     }];
    return result;
}


/**
 从相册获取照片
 */
- (void)myPhotoTap:(id)sender{
    
    UIImagePickerController *ctrl = [[UIImagePickerController alloc]init];
    ctrl.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    ctrl.delegate = self;
    //模态风格转换
    ctrl.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    // 可以编辑
    ctrl.allowsEditing = YES;
    [self presentViewController:ctrl animated:YES completion:nil];
    
}
#pragma mark - UIImagePickerController代理
//点击取消按钮调用
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

//选中一张图片的时候调用
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    NSString     *mediaType = info[UIImagePickerControllerMediaType];
    if ([mediaType isEqualToString:(__bridge NSString *)kUTTypeImage]){
        UIImage *aImage;
        if (info[UIImagePickerControllerEditedImage]) {
            aImage = info[UIImagePickerControllerEditedImage];
        }else{
            aImage = info[UIImagePickerControllerOriginalImage];
        }
        NSData *imageData = UIImageJPEGRepresentation(aImage, 0.1);
        
        if (imageData) {
            NSString *b64 = [imageData base64EncodedStringWithOptions:0];
            [EKFaceAPI checkingFaceInfoWithImageData:b64 complete:^(id JSON, NSError *error) {
                if (error) {
                    self.content.text = @"人脸检测失败！服务器通讯错误！";
                }else
                {
                    
                    NSDictionary *dic = (NSDictionary *)JSON;
                    NSString *faceid = [[[dic objectForKey:@"face"] objectAtIndex:0] objectForKey:@"face_id"];
                    NSLog(@"%@",[[[dic objectForKey:@"face"] objectAtIndex:0] objectForKey:@"face_id"]);
                    NSDictionary *parms = @{@"people_name":@"test",
                                            @"face_id":faceid
                                            
                                            };
                    [EKFaceAPI peopleAddWithParms:parms complete:^(id JSON, NSError *error) {
                        
                    }];
                    //6c909ea0c34c4f0cba8aeb65f8910e7b
                    self.content.text = [self DataTOjsonString:JSON];
//                    [self.content sizeToFit];
                }
                
            }];
        }
        
        
    }
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}
- (void)checkFace:(NSData *)imageData imageUrl:(NSString *)imageUrl face_id:(NSString *)face_id completeBlock:(block)completeBlock{
    if (imageData) {
        NSString *b64 = [imageData base64EncodedStringWithOptions:0];
        [EKFaceAPI checkingFaceInfoWithImageData:b64 complete:^(id JSON, NSError *error) {
            completeBlock(JSON,error);
            
        }];
        return;
    }
    if (imageUrl) {
        [EKFaceAPI checkingFaceInfoWithImgUrl:imageUrl complete:^(id JSON, NSError *error) {
            if (error) {
                self.content.text = @"人脸检测失败！服务器通讯错误！";
            }else
            {
                
                NSDictionary *dic = (NSDictionary *)JSON;
                NSLog(@"%@",[[[dic objectForKey:@"face"] objectAtIndex:0] objectForKey:@"face_id"]);
                self.content.text = [self DataTOjsonString:JSON];
                [self.content sizeToFit];
            }
        }];
        return;
    }
    if (face_id) {
        NSDictionary *param = [NSDictionary dictionaryWithObject:face_id forKey:@"face_id"];
        [EKFaceAPI checkMarkWithParms:param complete:^(id JSON, NSError *error) {
            if (error) {
                self.content.text = @"人脸检测失败！服务器通讯错误！";
            }else
            {
                
                NSDictionary *dic = (NSDictionary *)JSON;
                NSLog(@"%@",[[[dic objectForKey:@"face"] objectAtIndex:0] objectForKey:@"face_id"]);
                self.content.text = [self DataTOjsonString:JSON];
                [self.content sizeToFit];
            }
        }];
        return;
    }
    
}
-(NSString*)DataTOjsonString:(id)object
{
    NSString *jsonString = nil;
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:object
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    if (! jsonData) {
        NSLog(@"Got an error: %@", error);
    } else {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}
- (NSInteger)numberOfColumnsInMenu:(DropDownMenu *)menu {
    return 3;
}

- (NSInteger)menu:(DropDownMenu *)menu numberOfRowsInColumn:(NSInteger)column {
    if (column == 0) {
        return self.classify.count;
    }else if(column == 1) {
        return self.sort.count;
    }else {
        return self.choose.count;
    }
}

- (NSString *)menu:(DropDownMenu *)menu titleForRowAtIndexPath:(DrIndexPath *)indexPath {
    if (indexPath.column == 0) {
        return self.classify[indexPath.row];
    }else if(indexPath.column == 1) {
        return self.sort[indexPath.row];
    }else {
        return self.choose[indexPath.row];
    }
}

- (NSString *)menu:(DropDownMenu *)menu imageNameForRowAtIndexPath:(DrIndexPath *)indexPath {
    if (indexPath.column == 0 || indexPath.column == 1) {
        return @"baidu";
    }
    return nil;
}

- (NSString *)menu:(DropDownMenu *)menu imageForItemsInRowAtIndexPath:(DrIndexPath *)indexPath {
    if (indexPath.column == 0 && indexPath.item >= 0) {
        return @"baidu";
    }
    return nil;
}

- (NSString *)menu:(DropDownMenu *)menu detailTextForRowAtIndexPath:(DrIndexPath *)indexPath {
    if (indexPath.column < 2) {
        return [@(arc4random()%1000) stringValue];
    }
    return nil;
}

- (NSString *)menu:(DropDownMenu *)menu detailTextForItemsInRowAtIndexPath:(DrIndexPath *)indexPath {
    return [@(arc4random()%1000) stringValue];
}

- (NSInteger)menu:(DropDownMenu *)menu numberOfItemsInRow:(NSInteger)row inColumn:(NSInteger)column {
    if (column == 0) {
        if (row == 3) {
            return self.jiachang.count;
        }else if (row == 4) {
            return self.difang.count;
        }else if (row == 5) {
            return self.tese.count;
        }else if (row == 6) {
            return self.rihan.count;
        }else if (row == 7) {
            return self.xishi.count;
        }else if (row == 8) {
            return self.shaokao.count;
        }
    }
    return 0;
}

- (NSString *)menu:(DropDownMenu *)menu titleForItemsInRowAtIndexPath:(DrIndexPath *)indexPath {
    NSInteger row = indexPath.row;
    if (indexPath.column == 0) {
        if (row == 3) {
            return self.jiachang[indexPath.item];
        }else if (row == 4) {
            return self.tese[indexPath.item];
        }else if (row == 5) {
            return self.rihan[indexPath.item];
        }else if (row == 6) {
            return self.xishi[indexPath.item];
        }else if (row == 7) {
            return self.shaokao[indexPath.item];
        }
    }
    return nil;
}

- (void)menu:(DropDownMenu *)menu didSelectRowAtIndexPath:(DrIndexPath *)indexPath {
    if (indexPath.item >= 0) {
        NSLog(@"点击了 %ld - %ld - %ld 项目",indexPath.column,indexPath.row,indexPath.item);
    }else {
        NSLog(@"点击了 %ld - %ld 项目",indexPath.column,indexPath.row);
    }
}




//collection
-(void)buildSettings{
    NSArray *viewArr = [[NSBundle mainBundle] loadNibNamed:@"iphone_settings_view" owner:self options:nil];
    UIView *innerView = [viewArr objectAtIndex:0];
    CGRect frame = self.view.bounds;
    frame.origin.y = (self.view.frame.size.height/2 - frame.size.height/2)/2;
    innerView.frame = frame;
    [settingsView addSubview:innerView];
    
    [innerView setNeedsLayout];
    [innerView layoutIfNeeded];
    
    radiusLabel = (UILabel*)[innerView viewWithTag:100];
    radiusSlider = (UISlider*)[innerView viewWithTag:200];
    [radiusSlider addTarget:self action:@selector(updateDialSettings) forControlEvents:UIControlEventValueChanged];
    
    angularSpacingLabel = (UILabel*)[innerView viewWithTag:101];
    angularSpacingSlider = (UISlider*)[innerView viewWithTag:201];
    [angularSpacingSlider addTarget:self action:@selector(updateDialSettings) forControlEvents:UIControlEventValueChanged];
    
    xOffsetLabel = (UILabel*)[innerView viewWithTag:102];
    xOffsetSlider = (UISlider*)[innerView viewWithTag:202];
    [xOffsetSlider addTarget:self action:@selector(updateDialSettings) forControlEvents:UIControlEventValueChanged];
    
    exampleSwitch = (UISegmentedControl*)[innerView viewWithTag:203];
    [exampleSwitch addTarget:self action:@selector(switchExample) forControlEvents:UIControlEventValueChanged];
}

-(void)switchExample{
    type = (int)exampleSwitch.selectedSegmentIndex;
    CGFloat radius = 0 ,angularSpacing  = 0, xOffset = 0;
    
    if(type == 0){
        [dialLayout setCellSize:CGSizeMake(340, 100)];
        [dialLayout setWheelType:WHEELALIGNMENTLEFT];
        [dialLayout setShouldFlip:NO];
        
        radius = 300;
        angularSpacing = 18;
        xOffset = 70;
    }else if(type == 1){
        [dialLayout setCellSize:CGSizeMake(260, 50)];
        [dialLayout setWheelType:WHEELALIGNMENTCENTER];
        [dialLayout setShouldFlip:YES];
        
        radius = 320;
        angularSpacing = 5;
        xOffset = 124;
        
        
        
    }
    
    [radiusLabel setText:[NSString stringWithFormat:@"Radius: %i", (int)radius]];
    radiusSlider.value = radius/1000;
    [dialLayout setDialRadius:radius];
    
    [angularSpacingLabel setText:[NSString stringWithFormat:@"Angular spacing: %i", (int)angularSpacing]];
    angularSpacingSlider.value = angularSpacing / 90;
    [dialLayout setAngularSpacing:angularSpacing];
    
    [xOffsetLabel setText:[NSString stringWithFormat:@"X offset: %i", (int)xOffset]];
    xOffsetSlider.value = xOffset/320;
    [dialLayout setXOffset:xOffset];
    
    
    [collectionView reloadData];
    
}

-(void)updateDialSettings{
    CGFloat radius = radiusSlider.value * 1000;
    CGFloat angularSpacing = angularSpacingSlider.value * 80;
    CGFloat xOffset = xOffsetSlider.value * 320;
    
    [radiusLabel setText:[NSString stringWithFormat:@"Radius: %i", (int)radius]];
    [dialLayout setDialRadius:radius];
    
    [angularSpacingLabel setText:[NSString stringWithFormat:@"Angular spacing: %i", (int)angularSpacing]];
    [dialLayout setAngularSpacing:angularSpacing];
    
    [xOffsetLabel setText:[NSString stringWithFormat:@"X offset: %i", (int)xOffset]];
    [dialLayout setXOffset:xOffset];
    
    [dialLayout invalidateLayout];
    //[collectionView reloadData];
    NSLog(@"updateDialSettings");
}

-(void)toggleSettingsView{
    CGRect frame = settingsView.frame;
    if(showingSettings){
        editBtn.title = @"Edit";
        frame.origin.y = self.view.frame.size.height;
    }else{
        editBtn.title = @"Close";
        frame.origin.y = 44;
    }
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        settingsView.frame = frame;
    } completion:^(BOOL finished) {
        
    }];
    
    showingSettings = !showingSettings;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.items.count;
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

-(BOOL)prefersStatusBarHidden{
    return YES;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell *cell;
    if(type == 0){
        cell = [cv dequeueReusableCellWithReuseIdentifier:cellId forIndexPath:indexPath];
    }else{
        cell = [cv dequeueReusableCellWithReuseIdentifier:cellId2 forIndexPath:indexPath];
    }
    
    NSDictionary *item = [self.items objectAtIndex:indexPath.item];
    
    NSString *playerName = [item valueForKey:@"name"];
    UILabel *nameLabel = (UILabel*)[cell viewWithTag:101];
    [nameLabel setText:playerName];
    
    
    NSString *hexColor = [item valueForKey:@"color"];
    
    
    if(type == 0){
        NSString *imgURL = [item valueForKey:@"url"];
        UIImageView *imgView = (UIImageView*)[cell viewWithTag:100];
        [imgView setImage:nil];
        __block UIImage *imageProduct = [thumbnailCache objectForKey:imgURL];
        if(imageProduct){
            imgView.image = imageProduct;
        }
        else{
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
            dispatch_async(queue, ^{
                UIImage *image = [UIImage imageNamed:imgURL];
                dispatch_async(dispatch_get_main_queue(), ^{
                    imgView.image = image;
                    [thumbnailCache setValue:image forKey:imgURL];
                });
            });
        }
        
    }else{
        nameLabel.textColor = [self colorFromHex:hexColor];
    }
    
    
    return cell;
}



-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *item = [self.items objectAtIndex:indexPath.item];
    NSString *link = [item valueForKey:@"url"];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:link]];
}



- (unsigned int)intFromHexString:(NSString *)hexStr
{
    unsigned int hexInt = 0;
    // Create scanner
    NSScanner *scanner = [NSScanner scannerWithString:hexStr];
    // Tell scanner to skip the # character
    [scanner setCharactersToBeSkipped:[NSCharacterSet characterSetWithCharactersInString:@"#"]];
    // Scan hex value
    [scanner scanHexInt:&hexInt];
    return hexInt;
}

-(UIColor*)colorFromHex:(NSString*)hexString{
    unsigned int hexint = [self intFromHexString:hexString];
    
    // Create color object, specifying alpha as well
    UIColor *color =
    [UIColor colorWithRed:((CGFloat) ((hexint & 0xFF0000) >> 16))/255
                    green:((CGFloat) ((hexint & 0xFF00) >> 8))/255
                     blue:((CGFloat) (hexint & 0xFF))/255
                    alpha:1];
    
    return color;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
