//
//  ViewController.m
//  推动速移附着效果
//
//  Created by zou145688 on 15/10/13.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    UIView *view;
    UIView *view1;
    UIDynamicAnimator *dynamicAnimator;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    dynamicAnimator = [[UIDynamicAnimator alloc]initWithReferenceView:self.view];
    view = [[UIView alloc]initWithFrame:CGRectMake(50, 50, 50, 50)];
    view.backgroundColor = [UIColor grayColor];
    view.layer.masksToBounds = YES;
    view.layer.cornerRadius = 25.f;
    [self.view addSubview:view];
    view1 = [[UIView alloc]initWithFrame:CGRectMake(150, 150, 150, 150)];
    view1.backgroundColor = [UIColor redColor];
    view1.layer.masksToBounds = YES;
    view1.layer.cornerRadius = 75.f;
    [self.view addSubview:view1];
    UITapGestureRecognizer *tapG = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    [self.view addGestureRecognizer:tapG];
    
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)tapAction:(UITapGestureRecognizer *)sender{
//    推动效果
    [dynamicAnimator removeAllBehaviors];
    UIPushBehavior *push = [[UIPushBehavior alloc]initWithItems:@[view,view1] mode:UIPushBehaviorModeContinuous];
    push.pushDirection = CGVectorMake(1, 0);//移动方向
    push.magnitude = 0.1;//移动速度
    push.active = YES;
//   [dynamicAnimator addBehavior:push];
//    迅速移动效果
//    [dynamicAnimator removeAllBehaviors];
    UISnapBehavior *snap = [[UISnapBehavior alloc]initWithItem:view snapToPoint:[sender locationInView:self.view]];
    snap.damping = 0.5f;//震荡级别
    [dynamicAnimator addBehavior:snap];
//   吸附效果
    [dynamicAnimator removeAllBehaviors];
    UIAttachmentBehavior *attachment = [[UIAttachmentBehavior alloc]initWithItem:view1 offsetFromCenter:UIOffsetMake(0, 0) attachedToAnchor:[sender locationInView:self.view]];
    attachment.length = 120;
    attachment.damping = 0.5;
    attachment.frequency = 1;
//    [dynamicAnimator addBehavior:attachment];
    UIAttachmentBehavior *attachment1 = [[UIAttachmentBehavior alloc]initWithItem:view attachedToAnchor:[sender locationInView:self.view]];
    attachment1.damping = 0.2;
    attachment1.frictionTorque = .3;
    attachment1.frequency = 2;
    attachment1.length = 1;
    [dynamicAnimator addBehavior:attachment1];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
