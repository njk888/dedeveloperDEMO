//
//  ViewController.m
//  邮件发送demo
//
//  Created by zou145688 on 15/10/15.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"
#import <MessageUI/MessageUI.h>
#import "CustomSendMailViewController.h"
@interface ViewController ()<MFMailComposeViewControllerDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(120, 120, 120, 30)];
    btn.backgroundColor = [UIColor redColor];
    [btn addTarget:self action:@selector(sendEmail:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)sendEmail:(id)sender{
    //判读设备是否支持发送邮件若不支持则通过SMTP协议发送邮件
    Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
    if (mailClass != nil) {
        if ([mailClass canSendMail]) {
            [self displayMailComposeSheet];
        }else{
            [self luanchMailAppleDevice];
        }
    }else{
        [self customSendEmailView];
    }
}
//设备已有邮箱
- (void)displayMailComposeSheet{
    
    MFMailComposeViewController *mailComposeVC = [[MFMailComposeViewController alloc]init];
    mailComposeVC.mailComposeDelegate = self;
    [mailComposeVC setSubject:@"subject"];
    mailComposeVC.navigationBar.tintColor = [UIColor brownColor];
    NSArray *toRecipients = [NSArray arrayWithObjects:@"1456886160@qq.com", nil];
    [mailComposeVC setToRecipients:toRecipients];
    NSString *emailBody = [NSString
                           stringWithFormat:@"SystemVersion: %@ \n AppVersion: %@ \n 反馈信息:\n",                                           [[UIDevice currentDevice] systemVersion],
                           [[[NSBundle mainBundle] infoDictionary]
                            objectForKey:@"CFBundleShortVersionString"]];
    [mailComposeVC setMessageBody:emailBody isHTML:NO];
    [self presentViewController:mailComposeVC animated:YES completion:nil];
}
//打开设备添加邮箱
- (void)luanchMailAppleDevice{
    NSString *recipients = @"mailto:first@example.com&subject=my email!";
    //@"mailto:first@example.com?cc=second@example.com,third@example.com&subject=my email!";
    NSString *body = @"&body=email body!";
    
    NSString *email = [NSString stringWithFormat:@"%@%@", recipients, body];
    email = [email stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    
//    email = (NSString *)CFBridgingRelease(CFURLCreateStringByReplacingPercentEscapes(kCFAllocatorDefault, (CFStringRef)email, (CFStringRef)@"!*'();:@&=+$,/?%#[]"));
    [[UIApplication sharedApplication] openURL: [NSURL URLWithString:email]];
}
- (void)customSendEmailView{
    CustomSendMailViewController *custom = [[CustomSendMailViewController alloc]init];
    [self presentViewController:custom animated:YES completion:nil];
}
#pragma mark - MFMailComposeViewControllerDelegate
- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error{
    NSString *title = @"邮件发送提醒";
    NSString *msg;
    switch (result){
        case MFMailComposeResultCancelled:
            msg = @"邮件已被取消";
            break;
        case MFMailComposeResultSaved:
            msg = @"邮件保存成功";
            [self alertWithTitle:title msg:msg];
            break;
        case MFMailComposeResultSent:
            msg = @"邮件发送成功";
            [self alertWithTitle:title msg:msg];
            break;
        case MFMailComposeResultFailed:
            msg =@"邮件发送失败";
            [self alertWithTitle:title msg:msg];
            break;
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void) alertWithTitle: (NSString *)_title_ msg: (NSString *)msg{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:_title_
                                                    message:msg
                                                   delegate:nil
                                          cancelButtonTitle:@"好"
                                          otherButtonTitles:nil];
    [alert show];
    [self performSelector:@selector(dismissAlert:) withObject:alert afterDelay:1.0];
}
- (void)dismissAlert:(UIAlertView *)sender{
    [sender dismissWithClickedButtonIndex:[sender cancelButtonIndex] animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
