//
//  ViewController.h
//  复制粘贴
//
//  Created by zou145688 on 15/10/12.
//  Copyright (c) 2015年 zou145688. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) UILabel *lable;
@end

