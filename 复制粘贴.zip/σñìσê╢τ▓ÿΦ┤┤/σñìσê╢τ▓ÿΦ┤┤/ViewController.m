//
//  ViewController.m
//  复制粘贴
//
//  Created by zou145688 on 15/10/12.
//  Copyright (c) 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self menuController];
}
- (void)menuController{
    _lable = [[UILabel alloc]initWithFrame:CGRectMake(120, 120, 120, 30)];
    _lable.text = @"不好玩啊啊啊啊啊啊啊啊";
    _lable.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [self.view addSubview:_lable];
    _lable.userInteractionEnabled = YES;
    [_lable addGestureRecognizer:[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPress:)]];

}
- (void)longPress:(UILongPressGestureRecognizer *)longTap{
    if (longTap.state == UIGestureRecognizerStateBegan) {
        [self.lable becomeFirstResponder];
        _lable.backgroundColor = [UIColor lightGrayColor];
        UIMenuController *menu = [UIMenuController sharedMenuController];
        
        //复制
        UIMenuItem *copyItem = [[UIMenuItem alloc] initWithTitle:@"复制" action:@selector(copyItemClicked:)];
        
        //收藏
        UIMenuItem *collectItem = [[UIMenuItem alloc] initWithTitle:@"收藏" action:@selector(collectItemClicked:)];
        
        //举报
        UIMenuItem *reportItem = [[UIMenuItem alloc] initWithTitle:@"举报" action:@selector(reportItemClicked:)];
        
        menu.menuItems = @[copyItem,collectItem,reportItem];
        
        [menu setMenuVisible:YES animated:YES];
        
        [menu setTargetRect:_lable.frame inView:self.view];
    }
}
//必须实现
- (BOOL)canBecomeFirstResponder{
    return YES;
}
//必须实现
-(BOOL) canPerformAction:(SEL)action withSender:(id)sender{
    if (action == @selector(copyItemClicked:) || action == @selector(collectItemClicked:)|| action == @selector(reportItemClicked:)
        ) {
        return YES;
    }
    return [super canPerformAction:action withSender:sender]; //隐藏系统默认的菜单项
}
- (void)copyItemClicked:(id)sender{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    [pasteboard setString:_lable.text];
    NSLog(@"复制");
}
- (void)collectItemClicked:(id)sender{
    NSLog(@"收藏");
}
- (void)reportItemClicked:(id)sender{
    NSLog(@"举报");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
