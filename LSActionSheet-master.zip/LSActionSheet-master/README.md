# LSActionSheet
目前主流actionSheet效果，类似微信，微博
##使用方法
  '[LSActionSheet showWithTitle:@"退出后不会删除任何历史数据，下次登录依然可以使用本账号。" destructiveTitle:@"退出登录" otherTitles:@[@"1111",@"2222"] block:^(int index) {
        NSLog(@"-----%d",index);
    }];'


![image](https://github.com/lsmakethebest/LSActionSheet/blob/master/images/IMG_0094.PNG)