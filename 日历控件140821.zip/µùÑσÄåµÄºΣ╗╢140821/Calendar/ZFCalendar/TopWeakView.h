//
//  TopWeakView.h
//  Calendar
//
//  Created by zou145688 on 15/10/21.
//  Copyright © 2015年 张凡. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TopWeakView : UIView
@property (weak, nonatomic) UILabel *day1OfTheWeekLabel;
@property (weak, nonatomic) UILabel *day2OfTheWeekLabel;
@property (weak, nonatomic) UILabel *day3OfTheWeekLabel;
@property (weak, nonatomic) UILabel *day4OfTheWeekLabel;
@property (weak, nonatomic) UILabel *day5OfTheWeekLabel;
@property (weak, nonatomic) UILabel *day6OfTheWeekLabel;
@property (weak, nonatomic) UILabel *day7OfTheWeekLabel;
@end
