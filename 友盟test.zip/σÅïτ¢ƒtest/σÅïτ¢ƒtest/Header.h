//
//  Header.h
//  友盟test
//
//  Created by zou145688 on 15/10/26.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#ifndef Header_h
#define Header_h
#define UMAppkey @"562da05967e58ec7cd001826"
#define UMRedirectURL @"https://api.weibo.com/oauth2/default.html"
#define QQAppkey @"Z2zp6nrZkisj3uLG"
#define QQAppID @"1104918712"
#endif /* Header_h */
