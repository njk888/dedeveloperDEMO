//
//  ViewController.m
//  友盟test
//
//  Created by zou145688 on 15/10/26.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"
#import "UMSocial.h"
#import "Header.h"
#import "MobClick.h"
@interface ViewController ()<UMSocialUIDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *sinaBtn = [[UIButton alloc]initWithFrame:CGRectMake(120, 120, 130, 30)];
    sinaBtn.backgroundColor = [UIColor redColor];
    [sinaBtn setTitle:@"新浪微博分享" forState:UIControlStateNormal];
    [sinaBtn addTarget:self action:@selector(sinaShareAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sinaBtn];
    UIButton *QQbtn = [[UIButton alloc]initWithFrame:CGRectMake(120, 180, 130, 30)];
    QQbtn.backgroundColor = [UIColor greenColor];
    [QQbtn setTitle:@"QQ分享" forState:UIControlStateNormal];
    [QQbtn addTarget:self action:@selector(QQShareAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:QQbtn];
    UIButton *sinaLoginBtn = [[UIButton alloc]initWithFrame:CGRectMake(120, 240, 130, 30)];
    sinaLoginBtn.backgroundColor = [UIColor grayColor];
    [sinaLoginBtn setTitle:@"新浪微博登陆" forState:UIControlStateNormal];
    [sinaLoginBtn addTarget:self action:@selector(sinaLoginAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sinaLoginBtn];
    UIButton *QQLoginBtn = [[UIButton alloc]initWithFrame:CGRectMake(120, 300, 130, 30)];
    QQLoginBtn.backgroundColor = [UIColor grayColor];
    [QQLoginBtn setTitle:@"QQ登陆" forState:UIControlStateNormal];
    [QQLoginBtn addTarget:self action:@selector(QQLoginAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:QQLoginBtn];
    UIButton *sianQuitBtn = [[UIButton alloc]initWithFrame:CGRectMake(120, 350, 130, 30)];
    sianQuitBtn.backgroundColor = [UIColor grayColor];
    [sianQuitBtn setTitle:@"新浪微博退出" forState:UIControlStateNormal];
    [sianQuitBtn addTarget:self action:@selector(sianQuitAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sianQuitBtn];
    UIButton *QQuitBtn = [[UIButton alloc]initWithFrame:CGRectMake(120, 400, 130, 30)];
    QQuitBtn.backgroundColor = [UIColor grayColor];
    [QQuitBtn setTitle:@"QQ退出" forState:UIControlStateNormal];
    [QQuitBtn addTarget:self action:@selector(QQQuitAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:QQuitBtn];

    // Do any additional setup after loading the view, typically from a nib.
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"viewController"];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"viewController"];
}
- (void)sinaShareAction:(id)sender{
    [MobClick endEvent:@"2" label:@"b"];
    [MobClick profileSignInWithPUID:@"1" provider:@"a"];
//    1.使用友盟默认提供的分享面板
//    [UMSocialSnsService presentSnsIconSheetView:self
//                                         appKey:UMAppkey
//                                      shareText:@"友盟社会化分享让您快速实现分享等社会化功能，http://umeng.com/social"
//                                     shareImage:[UIImage imageNamed:@"icon.png"]
//                                shareToSnsNames:@[UMShareToSina]
//                                       delegate:self];
//    2.自己定义的分享列表，但仍然使用友盟分享编辑页
//    [[UMSocialControllerService defaultControllerService] setShareText:@"分享内嵌文字" shareImage:[UIImage imageNamed:@"icon"] socialUIDelegate:self];        //设置分享内容和回调对象
//    [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina].snsClickHandler(self,[UMSocialControllerService defaultControllerService],YES);
//    3.直接分享接口，分享过程没有分享编辑页，适用于希望直接在后台进行分享或希望自定义分享编辑页的开发者
//    [[UMSocialDataService defaultDataService]  postSNSWithTypes:@[UMShareToSina] content:@"分享内嵌文字" image:nil location:nil urlResource:nil presentedController:self completion:^(UMSocialResponseEntity *shareResponse){
//        if (shareResponse.responseCode == UMSResponseCodeSuccess) {
//            NSLog(@"分享成功！");
//        }
//    }];
//    4.分享URL图片,同样可以分享音乐，视频
//    4.1 分享过程中一次只能上传一个图片，因此URL图片和本地图片不可共存，当两者都存在时会默认忽略本地图片.使用默认分享界面分享URL图片
//    [[UMSocialData defaultData].urlResource setResourceType:UMSocialUrlResourceTypeImage url:@"http://www.baidu.com/img/bdlogo.gif"];
    
        //调用快速分享接口
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:UMAppkey
                                      shareText:@"友盟社会化分享让您快速实现分享等社会化功能，http://umeng.com/social"
                                     shareImage:[UIImage imageNamed:@"Default@2x"]
                                shareToSnsNames:@[UMShareToSina]
                                       delegate:self];
//    4.2使用自定义界面分享URL图片
//    UMSocialUrlResource *urlResource = [[UMSocialUrlResource alloc] initWithSnsResourceType:UMSocialUrlResourceTypeImage url:
//                                        @"http://www.baidu.com/img/bdlogo.gif"];
//    [[UMSocialDataService defaultDataService]  postSNSWithTypes:@[UMShareToSina] content:@"分享内嵌文字" image:nil location:nil urlResource:urlResource presentedController:self completion:^(UMSocialResponseEntity *shareResponse){
//        if (shareResponse.responseCode == UMSResponseCodeSuccess) {
//            NSLog(@"分享成功！");
//        }
//    }];
}


//实现回调方法（可选）：
-(void)didFinishGetUMSocialDataInViewController:(UMSocialResponseEntity *)response
{
    //根据`responseCode`得到发送结果,如果分享成功
    if(response.responseCode == UMSResponseCodeSuccess)
    {
        //得到分享到的微博平台名
        NSLog(@"share to sns name is %@",[[response.data allKeys] objectAtIndex:0]);
    }
}
- (void)QQShareAction:(id)sender{
    [UMSocialSnsService presentSnsIconSheetView:self
                                         appKey:UMAppkey
                                      shareText:@"友盟社会化分享让您快速实现分享等社会化功能，www.umeng.com/social"
                                     shareImage:[UIImage imageNamed:@"Default@2x.png"]
                                shareToSnsNames:@[UMShareToQQ,UMShareToQzone]
                                       delegate:self];
}
- (void)sinaLoginAction:(id)sender{
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
    
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        
        //          获取微博用户名、uid、token等
        
        if (response.responseCode == UMSResponseCodeSuccess) {
            
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
            
            NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
            [[UMSocialDataService defaultDataService] requestSnsFriends:UMShareToSina completion:^(UMSocialResponseEntity *response) {
                if (response.responseCode == UMSResponseCodeSuccess) {
                    NSLog(@"SnsFriends is %@",response.data);
                }
            }];
            
        }});
}
- (void)sianQuitAction:(id)sender{
    [[UMSocialDataService defaultDataService] requestUnOauthWithType:UMShareToSina  completion:^(UMSocialResponseEntity *response){
        NSLog(@"response is %@",response);
    }];
}
- (void)QQLoginAction:(id)sender{
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToQQ];
    
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        
        //          获取微博用户名、uid、token等
        
        if (response.responseCode == UMSResponseCodeSuccess) {
            
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToQQ];
            
            NSLog(@"username is %@, uid is %@, token is %@ url is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
            
        }});
}
- (void)QQQuitAction:(id)sender{
    [[UMSocialDataService defaultDataService] requestUnOauthWithType:UMShareToQQ  completion:^(UMSocialResponseEntity *response){
        if (response.responseCode == UMSResponseCodeSuccess) {
            NSLog(@"response is %@",response);
        }
        
    }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
