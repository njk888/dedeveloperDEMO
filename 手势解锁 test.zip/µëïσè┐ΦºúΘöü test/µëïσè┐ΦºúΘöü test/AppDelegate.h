//
//  AppDelegate.h
//  手势解锁 test
//
//  Created by 邹壮壮 on 16/9/22.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

