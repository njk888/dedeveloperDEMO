//
//  ZZUnlockView.m
//  手势解锁 test
//
//  Created by 邹壮壮 on 16/9/22.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "ZZUnlockView.h"

#define BUTTON_COUNT 9
#define BUTTON_COL_COUNT 3
#define BUTTON_WIDTH 74
#define BUTTON_HEIGHT 74


@interface ZZUnlockView()

//所有按钮
@property(nonatomic,strong)NSMutableArray *buttonsArray;
//被选中按钮
@property(nonatomic,strong)NSMutableArray *selectedbuttonsArray;

@end

@implementation ZZUnlockView

/** 初始化数组 */
- (NSMutableArray *)buttonsArray{
    if (!_buttonsArray) {
        _buttonsArray = [NSMutableArray array];
    }
    return _buttonsArray;
}
- (NSMutableArray *)selectedbuttonsArray{
    if (!_selectedbuttonsArray) {
        _selectedbuttonsArray = [NSMutableArray array];
    }
    return _selectedbuttonsArray;
}

#pragma mark - 初始化方法
/** 使用文件初始化 */
- (id)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self initView];
    }
    return self;
}

/** 使用代码初始化 */
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initView];
    }
    return self;
}

/** 初始化view内的控件(按钮) */
- (void) initView {
    // 设置透明背景
    
    self.backgroundColor = [[UIColor alloc] initWithRed:1 green:1 blue:1 alpha:0];
    for (int i=0; i<BUTTON_COUNT; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.userInteractionEnabled = NO;
        [button setBackgroundImage:[UIImage imageNamed:@"gesture_node_normal"] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:@"gesture_node_highlighted"] forState:UIControlStateSelected];
        // 设置指标tag，用来记录轨迹
        button.tag = i;
        // 加入按钮到lock view
        [self.buttonsArray addObject:button];
        [self addSubview:button];
    }
}

/** 设置按钮位置尺寸 */
- (void)layoutSubviews {
    [super layoutSubviews];
    
    // 取出所有按钮
    for (int i=0; i<self.buttonsArray.count; i++) {
        UIButton *button = self.buttonsArray[i];
        CGFloat buttonWidth = 74;
        CGFloat buttonHeight = 74;
        
        // 此按钮所在列号
        int col = i % BUTTON_COL_COUNT;
        // 此按钮所在行号
        int row = i / BUTTON_COL_COUNT;
        // 等分水平多余空间，计算出间隙
        CGFloat marginX = (self.frame.size.width - BUTTON_COL_COUNT * buttonWidth) / (BUTTON_COL_COUNT + 1);
        CGFloat marginY = marginX;
        
        // x坐标
        CGFloat buttonX = marginX + col * (buttonWidth + marginX);
        // y坐标
        CGFloat buttonY = marginY + row * (buttonHeight + marginY);
        
        button.frame = CGRectMake(buttonX, buttonY, buttonWidth, buttonHeight);
    }
}

#pragma mark - 触摸事件
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = touches.anyObject;
    CGPoint point = [touch locationInView:touch.view];
    for (int i=0; i<self.buttonsArray.count; i++) {
        
        UIButton *btn = self.buttonsArray[i];
        if (CGRectContainsPoint(btn.frame, point)&&!btn.selected){
            btn.selected = YES;
            
            [self.selectedbuttonsArray addObject:btn];
            break;
        }
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    
    UITouch *touch = touches.anyObject;
    CGPoint point = [touch locationInView:touch.view];
    
    
    for (int i=0; i<self.buttonsArray.count; i++) {
        UIButton *btn = self.buttonsArray[i];
        if (CGRectContainsPoint(btn.frame, point)&&!btn.selected){
            btn.selected = YES;
            [self.selectedbuttonsArray addObject:btn];
            
            break;
            
        }
    }
    [self setNeedsDisplay];
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    
    // 轨迹序列
    NSMutableString *passPath = [NSMutableString string];
    for (UIButton *button in self.selectedbuttonsArray) {
        [passPath appendFormat:@"%ld", button.tag];
    }
    if ([self.delegate respondsToSelector:@selector(ZZUnLockView:didFinishedWithPath:)]) {
        [self.delegate ZZUnLockView:self didFinishedWithPath:passPath];
    }
    [self setNeedsDisplay];
    
    
    
}

#pragma mark - 绘图方法
- (void)drawRect:(CGRect)rect {
    if (self.selectedbuttonsArray.count==0)return;
    UIBezierPath *path = [UIBezierPath bezierPath];
    for (int i=0;i<self.selectedbuttonsArray.count; i++) {
        UIButton *btn = self.selectedbuttonsArray[i];
        if (i==0) {
            [path moveToPoint:btn.center];
        }else {
            [path addLineToPoint:btn.center];
        }
        
    }
    // 设置画笔
    [[UIColor redColor] set];
    [path setLineWidth:10];
    [path setLineCapStyle:kCGLineCapRound];
    [path setLineJoinStyle:kCGLineJoinBevel];
    [path stroke];
}
@end
