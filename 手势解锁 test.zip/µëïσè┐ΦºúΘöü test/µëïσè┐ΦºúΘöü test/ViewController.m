//
//  ViewController.m
//  手势解锁 test
//
//  Created by 邹壮壮 on 16/9/22.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import "ViewController.h"
#import "ZZUnlockView.h"
@interface ViewController ()<ZZUnlockViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"Home_refresh_bg"]];
    ZZUnlockView *zzUnlockView = [[ZZUnlockView alloc]initWithFrame:CGRectMake(0, 44, self.view.frame.size.width, self.view.frame.size.height)];
    zzUnlockView.delegate = self;
    [self.view addSubview:zzUnlockView];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)ZZUnLockView:(ZZUnlockView *)ZZUnLockView didFinishedWithPath:(NSString *)path{
    NSLog(@"%@",path);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
