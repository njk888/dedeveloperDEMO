//
//  ZZUnlockView.h
//  手势解锁 test
//
//  Created by 邹壮壮 on 16/9/22.
//  Copyright © 2016年 邹壮壮. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ZZUnlockView;
@protocol ZZUnlockViewDelegate <NSObject>

@optional
- (void) ZZUnLockView:(ZZUnlockView *) ZZUnLockView didFinishedWithPath:(NSString *) path;

@end
@interface ZZUnlockView : UIView
@property (nonatomic,weak)id<ZZUnlockViewDelegate>delegate;
@end
