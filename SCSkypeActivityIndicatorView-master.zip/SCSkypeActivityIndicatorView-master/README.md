# SCSkypeActivityIndicatorView
SCSkypeActivityIndicatorView is an activity indicator view similar to the one seen in the Skype apps.

 Normal Skype look&feel |  Customized
:--------------------------:|:--------------------------:
![](https://dl.dropboxusercontent.com/u/12748201/SCSkypeActivityIndicatorView/SCSkypeActivityIndicatorView1.gif) | ![](https://dl.dropboxusercontent.com/u/12748201/SCSkypeActivityIndicatorView/SCSkypeActivityIndicatorView2.gif)

##### Try out the demo project for more details (pod try)

## License
SCSkypeActivityIndicatorView is released under the MIT License (MIT) (see the LICENSE file)

## Contact
Any suggestions or improvements are more than welcome.
Feel free to contact me at [stefan.ceriu@yahoo.com](mailto:stefan.ceriu@yahoo.com) or [@stefanceriu](https://twitter.com/stefanceriu).
