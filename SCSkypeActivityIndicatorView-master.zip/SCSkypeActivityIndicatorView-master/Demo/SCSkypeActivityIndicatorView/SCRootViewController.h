//
//  SCRootViewController.h
//  SCSkypeActivityIndicatorView
//
//  Created by Stefan Ceriu on 12/01/2014.
//  Copyright (c) 2014 Stefan Ceriu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCRootViewController : UIViewController

@end
