//
//  ViewController.h
//  ZBarSDKdemo
//
//  Created by zou145688 on 15/10/12.
//  Copyright (c) 2015年 zou145688. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"
@interface ViewController : UIViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate,ZBarReaderDelegate>
{
    int num;
    BOOL upOrDown;
    NSTimer *timer;
}
@property (nonatomic, strong)UIImageView *lineImage;
@end

