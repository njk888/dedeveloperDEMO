//
//  ViewController.m
//  ZBarSDKdemo
//
//  Created by zou145688 on 15/10/12.
//  Copyright (c) 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
@interface ViewController ()

@end

@implementation ViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton * scanButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [scanButton setTitle:@"扫描" forState:UIControlStateNormal];
    scanButton.frame = CGRectMake(100, 100, 120, 40);
    [scanButton addTarget:self action:@selector(setupCamera) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:scanButton];
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)setupCamera{
    num = 0;
    upOrDown = NO;
    ZBarReaderViewController *rearderVC = [ZBarReaderViewController new];
    rearderVC.readerDelegate = self;
    rearderVC.supportedOrientationsMask = ZBarOrientationMaskAll;
    rearderVC.scanCrop = CGRectMake(0, 0, 10, 10);
    ZBarImageScanner *scanner = rearderVC.scanner;
    [scanner setSymbology:ZBAR_I25 config:ZBAR_CFG_ENABLE to:0];
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 420)];
    UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(20, 20, 280, 40)];
    label.text = @"请将扫描的二维码至于下面的框内\n谢谢！";
    label.textColor = [UIColor whiteColor];
    label.textAlignment = 1;
    label.lineBreakMode = 0;
    label.numberOfLines = 2;
    label.backgroundColor = [UIColor clearColor];
    [view addSubview:label];
    view.backgroundColor = [UIColor clearColor];
    UIImageView * image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pick_bg.png"]];
    image.frame = CGRectMake(20, 80, 280, 280);
    [view addSubview:image];
    _lineImage = [[UIImageView alloc] initWithFrame:CGRectMake(30, 10, 220, 2)];
    _lineImage.image = [UIImage imageNamed:@"line.png"];
    [image addSubview:_lineImage];
    //定时器，设定时间过1.5秒，
    timer = [NSTimer scheduledTimerWithTimeInterval:.02 target:self selector:@selector(animation1) userInfo:nil repeats:YES];
    rearderVC.cameraOverlayView = view;
    [self presentViewController:rearderVC animated:YES completion:^{
        
    }];
}
-(void)animation1
{
    if (upOrDown == NO) {
        num ++;
        _lineImage.frame = CGRectMake(30, 10+2*num, 220, 2);
        if (2*num == 260) {
            upOrDown = YES;
        }
    }
    else {
        num --;
        _lineImage.frame = CGRectMake(30, 10+2*num, 220, 2);
        if (num == 0) {
            upOrDown = NO;
        }
    }
    
    
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [timer invalidate];
    _lineImage.frame = CGRectMake(30, 10, 220, 2);
    num = 0;
    upOrDown = NO;
    [picker dismissViewControllerAnimated:YES completion:^{
        [picker removeFromParentViewController];
    }];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    [timer invalidate];
    _lineImage.frame = CGRectMake(30, 10, 220, 2);
    num = 0;
    upOrDown = NO;
    [picker dismissViewControllerAnimated:YES completion:^{
        [picker removeFromParentViewController];
        
        //初始化
        ZBarReaderController * read = [ZBarReaderController new];
        //设置代理
        read.readerDelegate = self;
        
        ZBarSymbol * symbol = nil;
        id <NSFastEnumeration> results = [info objectForKey:ZBarReaderControllerResults];
        for (symbol in results)
        {
            break;
        }
        NSString * result;
        if ([symbol.data canBeConvertedToEncoding:NSShiftJISStringEncoding])
            
        {
            result = [NSString stringWithCString:[symbol.data cStringUsingEncoding: NSShiftJISStringEncoding] encoding:NSUTF8StringEncoding];
        }
        else
        {
            result = symbol.data;
        }
        NSURL *url = [NSURL URLWithString:result];
        [[UIApplication sharedApplication]openURL:url];
        
        NSLog(@"%@",result);
        
    }];

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
