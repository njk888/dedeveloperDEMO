//
//  AppDelegate.h
//  TimerHelper
//
//  Created by develop on 15/9/15.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

