//
//  ViewController.m
//  定位test
//
//  Created by zou145688 on 15/10/27.
//  Copyright © 2015年 zou145688. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>
@interface ViewController ()<CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    定位管理器
    locationManager = [[CLLocationManager alloc]init];
    if (![locationManager locationServicesEnabled]) {
        NSLog(@"去那个打开");
        return;
    }
    if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusNotDetermined) {
        [locationManager requestWhenInUseAuthorization];
    }else if ([CLLocationManager authorizationStatus] == kCLAuthorizationStatusAuthorizedWhenInUse){
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest;
        CLLocationDistance distance = 10.0;
        locationManager.distanceFilter = distance;
        [locationManager startUpdatingLocation];
    }
    // Do any additional setup after loading the view, typically from a nib.
}
- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
    [locationManager stopUpdatingLocation];
    CLGeocoder * geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation:newLocation completionHandler:^(NSArray *placemarks, NSError *error) {
        
        if (placemarks.count > 0) {
            
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            NSString *city = placemark.locality;
            NSString *cityName;
            if (!city){
                cityName = placemark.administrativeArea;
            }
            
            if (city) {
                cityName = placemark.locality;
                //
            }
            //                for (NSDictionary *dic in cityListArray) {
            //                    NSString *cityNames = [dic objectForKey:@"name"];
            //                    if ([cityName rangeOfString:cityNames].location != NSNotFound) {
            //                        NSString *cityID = [NSString stringWithFormat:@"%@",[dic objectForKey:@"id"]];
            //                        [[NSUserDefaults standardUserDefaults]setObject:cityID forKey:@"YES"];
            //                        [[NSUserDefaults standardUserDefaults]setObject:dic forKey:@"cityLable"];
            //                    }
            //                }
            
        }
    }];
    CLLocation *location = [locationManager location];
    
    CLLocationCoordinate2D coord;
    coord.longitude = location.coordinate.longitude;
    coord.latitude = location.coordinate.latitude;
    
    if (coord.longitude && coord.latitude) {
//        [[NSUserDefaults standardUserDefaults] setDouble:coord.longitude forKey:MY_LOCATION_LONGITUDE];
//        [[NSUserDefaults standardUserDefaults] setDouble:coord.latitude forKey:MY_LOCATION_LATITUDE];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }

}
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations{
    CLLocation *location=[locations firstObject];//取出第一个位置
    CLLocationCoordinate2D coordinate=location.coordinate;//位置坐标
    CLGeocoder * geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        
        if (placemarks.count > 0) {
            
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            NSString *city = placemark.locality;
            NSString *cityName;
            if (!city){
                cityName = placemark.administrativeArea;
            }
            
            if (city) {
                cityName = placemark.locality;
                //
            }
            //                for (NSDictionary *dic in cityListArray) {
            //                    NSString *cityNames = [dic objectForKey:@"name"];
            //                    if ([cityName rangeOfString:cityNames].location != NSNotFound) {
            //                        NSString *cityID = [NSString stringWithFormat:@"%@",[dic objectForKey:@"id"]];
            //                        [[NSUserDefaults standardUserDefaults]setObject:cityID forKey:@"YES"];
            //                        [[NSUserDefaults standardUserDefaults]setObject:dic forKey:@"cityLable"];
            //                    }
            //                }
            
        }
    }];

    NSLog(@"经度：%f,纬度：%f,海拔：%f,航向：%f,行走速度：%f",coordinate.longitude,coordinate.latitude,location.altitude,location.course,location.speed);
    //如果不需要实时定位，使用完即使关闭定位服务
    [locationManager stopUpdatingLocation];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
