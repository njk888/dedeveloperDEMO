//
//  WCLRecordVideoVC.h
//  Youqun
//
//  Created by 王崇磊 on 16/5/16.
//  Copyright © 2016年 W_C__L. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WCLRecordVideoVC :UIViewController


@end
