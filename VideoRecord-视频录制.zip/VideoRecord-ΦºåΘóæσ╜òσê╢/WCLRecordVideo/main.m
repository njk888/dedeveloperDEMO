//
//  main.m
//  WCLRecordVideo
//
//  Created by 王崇磊 on 16/5/24.
//  Copyright © 2016年 王崇磊. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
