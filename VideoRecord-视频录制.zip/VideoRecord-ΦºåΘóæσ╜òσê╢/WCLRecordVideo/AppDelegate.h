//
//  AppDelegate.h
//  WCLRecordVideo
//
//  Created by 王崇磊 on 16/5/24.
//  Copyright © 2016年 王崇磊. All rights reserved.
//
// 博客地址：http://blog.csdn.net/wang631106979/article/details/51498009

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

