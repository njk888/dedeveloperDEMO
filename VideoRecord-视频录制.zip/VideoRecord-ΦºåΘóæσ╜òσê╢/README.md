# VideoRecoder

用AVFoundation自定义视频录制功能，包含：横竖屏录制、断点录制、前后摄像头、闪光灯、手动聚焦等,还可设置最低和最高录制时间

## 声明

首先我要声明的是：这个demo是修改自[WCLRecordVideo](https://github.com/631106979/WCLRecordVideo)，仅用来大家互相学习，如果侵犯了原作者利益，请及时指出
<br>欢迎下载、欢迎指导、欢迎star。</br>

![image](https://github.com/haolizi/VideoRecord/blob/master/etc.gif)




