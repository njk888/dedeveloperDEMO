//
//  NSObject+MKASAdditions.h
//  MKActionSheet
//
//  Created by xiaomk on 16/8/6.
//  Copyright © 2016年 MK. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (MKASAdditions)

@property (nonatomic, assign) BOOL mk_isSelect;

@end
