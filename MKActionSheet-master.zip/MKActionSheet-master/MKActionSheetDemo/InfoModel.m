//
//  InfoModel.m
//  MKActionSheet
//
//  Created by xiaomk on 16/8/4.
//  Copyright © 2016年 MK. All rights reserved.
//

#import "InfoModel.h"
@implementation InfoModel
@end

@implementation OtherModel
@end
